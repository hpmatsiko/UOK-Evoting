<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Your Generated Code</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            padding: 20px;
            color: #333;
        }
        .container {
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
        }
        .code-box {
            background-color: #e0e0e0;
            padding: 15px;
            text-align: center;
            font-size: 24px;
            font-weight: bold;
            border-radius: 5px;
        }
        h2 {
            color: #4CAF50;
        }
        p {
            font-size: 16px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Your Generated Code</h2>
        <p>Hello, {{ $user->fname }} {{ $user->lname }},</p>
        <p>Your generated code is:</p>
        <div class="code-box">
            {{ $generatedCode }}
        </div>
        <p>Thank you for using our service.</p>
        <p>Best regards,<br>Your Application Team</p>
    </div>
</body>
</html>
