@extends('user.common')

@section('title', 'Home Page')

@section('content')
<div class="container my-5">
    <h4 class="text-center mb-4">All Candidates</h4>

    @foreach ($groupedCandidates as $categoryId => $groupedCandidates)
        <h3 class="mt-4">{{ $groupedCandidates->first()->category->category }}</h3>
        <div class="row">
            @foreach ($groupedCandidates as $candidate)
                @if ($candidate->user)
                    <div class="col-lg-3 col-md-4 col-sm-6 mb-4">
                        <a href="{{ route('vote.form', ['candidate_id' => $candidate->id]) }}" class="card h-100 shadow-sm text-decoration-none">
                            <img src="{{ asset('images/' . $candidate->user->image) }}" class="card-img-top" alt="{{ $candidate->user->fname }}'s Image" style="height: 200px; object-fit: cover;">
                            <div class="card-body">
                                <h5 class="card-title">{{ $candidate->user->fname }} {{ $candidate->user->lname }}</h5>
                                <p class="card-text">{{ $candidate->votes_count }} Votes</p>
                                <div class="progress">
                                    @php
                                        // Generate a random color for the progress bar
                                        $randomColor = sprintf('#%06X', mt_rand(0, 0xFFFFFF));
                                    @endphp
                                    <div class="progress-bar" role="progressbar" style="width: {{ $candidate->votes_percentage }}%; background-color: {{ $randomColor }};" aria-valuenow="{{ $candidate->votes_percentage }}" aria-valuemin="0" aria-valuemax="100">
                                        {{ $candidate->votes_percentage }}%
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>
                @else
                    <div class="col-lg-3 col-md-4 col-sm-6 mb-4">
                        <div class="card h-100 shadow-sm">
                            <div class="card-body">
                                <h5 class="card-title">Unknown Candidate</h5>
                                <p class="card-text">No image available</p>
                                <p class="card-text">{{ $candidate->votes_count }} Votes</p>
                                <div class="progress">
                                    @php
                                        // Generate a random color for the progress bar
                                        $randomColor = sprintf('#%06X', mt_rand(0, 0xFFFFFF));
                                    @endphp
                                    <div class="progress-bar" role="progressbar" style="width: 0%; background-color: {{ $randomColor }};" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100">
                                        0%
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                @endif
            @endforeach
        </div>
    @endforeach

    <div class="d-flex justify-content-center mt-4">
        {{ $candidates->links('pagination::bootstrap-4') }}
    </div>
</div>
@endsection
