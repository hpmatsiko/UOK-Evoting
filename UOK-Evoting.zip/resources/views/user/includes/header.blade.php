
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
<style>
    /* General Styles */
    body {
        font-family: Arial, sans-serif;
    }

    .navbar{
        background-color: #e88310;
        padding: 1rem;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        z-index: 99999999999;
  }
    .navbar-brand img {
        height: 70px;
    }

    .navbar-nav .nav-link {
        color: black;
        font-weight: 500;
        text-transform: capitalize;
    }

    .navbar-nav .nav-link:hover {
        color: #006600;
    }

    .dropdown-menu {
        border-radius: 0;
        border: none;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    }

    .dropdown-item:hover {
        background-color: #f8f9fa;
    }

    .navbar-toggler {
        border: none;
    }

    .navbar-toggler:focus {
        outline: none;
    }

    .form-inline {
        display: flex;
        align-items: center;
    }

    .form-inline input {
        border: none;
        border-bottom: 1px solid #ccc;
        border-radius: 0;
        margin-right: 0.5rem;
    }

    .form-inline input:focus {
        box-shadow: none;
    }

    @media (max-width: 991px) {
        .navbar-collapse {
            background-color: black;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            margin-top: 1rem;
            padding: 1rem;
        }

        .navbar-nav {
            margin-top: 1rem;
        }

        .navbar-nav .nav-item {
            margin-bottom: 1rem;
        }

        .form-inline {
            flex-direction: column;
            align-items: flex-start;
        }

        .form-inline input {
            margin-bottom: 0.5rem;
            width: 100%;
        }
    }
</style>

<script type="text/javascript">
    function toggle()
    {
        var button=document.querySelector('.navbar-toggler');
        var content=document.querySelector('#navbarContent');
        if (content.style.display==='block') {
            content.style.display='none';
        }

        else
        {

            content.style.display='block';

        }
    }
</script>

<nav style="background-color: wheat;" class="navbar navbar-expand-lg navbar-light navbar-custom sticky-top">


    <div class="collapse navbar-collapse" id="navbarContent">
        <ul class="navbar-nav ml-auto">



            <li class="nav-item">
                <a style="color: black;" href="{{ route('ChooseCat') }}" class="nav-link wow">I want to be a candidate</a>

              </li>
            <li class="nav-item">
              <a style="color: black;" href="{{ route('user') }}" class="nav-link wow">Candidates</a>

            </li>

            <li class="nav-item">
                <a style="color: black;" href="{{ route('vk') }}" class="nav-link wow">Key</a>

              </li>

        <li class="nav-item dropdown">
            <a style="color: black;" class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" data-wow-delay="1.2s">
                {{ Auth::user()->fname }} {{ Auth::user()->lname }}
            </a>
            <div class="dropdown-menu" aria-labelledby="userDropdown">
                <a class="dropdown-item" href="{{ route('profile.edit') }}">My Acount</a>
                <form method="POST" action="{{ route('logout') }}">
                    @csrf
                    <button class="dropdown-item" type="submit">Logout</button>
                </form>
            </div>
        </li>
    </ul>
</div>
</nav>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

<script type="text/javascript">
 function toggle() {
    var content = document.querySelector('#navbarContent');
    if (content.style.display === 'block') {
        content.style.display = 'none';
    } else {
        content.style.display = 'block';
    }
}


</script>
<div >
 <div class="container-xxl">
    <div class="container">
        <div class="row g-4" id="search_list">


        </div>
    </div>
</div>
</div>
