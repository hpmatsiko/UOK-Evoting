@extends('user.common')
@section('title','Home Page')
@section('content')

<script type="text/javascript">
  function mvh() {
    var hid=document.querySelector('#forg');
    if (hid.style.display=='none') {
      hid.style.display='block';
      document.querySelector('.center2').style.display='none';
    } else {
      hid.style.display='none';
    }
  }
</script>
@php
                                // Generate a random hex color
$randomColor = sprintf('#%06X', mt_rand(0, 0xFFFFFF));
@endphp
<div id="forg" class="d-flex justify-content-center shadow" style="display: flex; width: 100%;background:wheat">
  <div class="wow shadow " data-wow-delay="1.5s" style="background: wheat;position: absolute; top: 30%; padding: 0; border-radius: 2vh; width: 50%;z-index: 900000; ">

    <div style="background: wheat"  class="form_container mt-5">

      @if(session('message'))
      <div class="alert alert-success">
          {{ session('message') }}
      </div>
  @endif
      <x-auth-session-status class="mb-4" :status="session('status')" />
      <form style="background: wheat" name="form" id="register2" action="{{ route('key') }}" method="post">
        @csrf
        <div>
          <div class="form_wrap">
            <div class="form_item mb-3">
              <input id="regN" class="form-control" type="regN" name="regN" :value="old('regN')" required autofocus autocomplete="regN" placeholder="Put REN to Request Voting Key"/>
              <x-input-error :messages="$errors->get('regN')" class="mt-2" />
              </div>
            </div>


                <div class="d-flex justify-content-end mt-4">

                  @php
                                // Generate a random hex color
                  $randomColor = sprintf('#%06X', mt_rand(0, 0xFFFFFF));
                  @endphp
                  <button type="submit" class="btn ms-3" style="background:{{ $randomColor }}; border: none; color: black;">
                    Request Key
                  </button>
                </div>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>

    @endsection
