@extends('user.common')

@section('title', 'Vote for Candidate')

@section('content')
<div class="container my-5 col-md-6 pt-5">
    <h4 class="text-center mb-4">Vote for Candidate</h4>

    <div class="card">
        <div class="card-header">
            Vote for {{ $candidate->user->fname }} {{ $candidate->user->lname }}
        </div>
        <div class="card-body">
            @if ($errors->any())
                <div class="alert alert-danger">
                    <ul>
                        @foreach ($errors->all() as $error)
                            <li>{{ $error }}</li>
                        @endforeach
                    </ul>
                </div>
            @endif

            @if(session()->has('suc'))
            <!-- Display success message -->
            <div class="alert alert-success">
                {{ session('suc') }}
            </div>
            @endif

            <form method="POST" action="{{ route('vote.submit') }}">
                @csrf
                <input type="hidden" name="candidate_id" value="{{ $candidate->id }}">
                <input type="hidden" name="category_id" value="{{ $candidate->category_id }}">
                <div class="row justify-content-center">
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label for="generated_code" class="form-label">Voting key</label>
                            <input type="text" class="form-control" id="generated_code" name="generated_code" required value="{{ old('generated_code') }}">
                        </div>
                        <div class="text-center">
                            <button type="submit" class="btn btn-primary">Submit Vote</button>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
@endsection
