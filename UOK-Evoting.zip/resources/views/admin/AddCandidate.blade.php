@extends('user.common')
@section('title', 'Add Candidate')
@section('content')

<style type="text/css">
    #teac {
        color: #6C7293;
    }
    #teach {
        background: #000000;
    }
</style>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<div class="container-fluid pt-4 px-4" style="margin-top: 6vh;">
    <div class="row g-4">
        <div class="col-sm-12 col-xl-6" style="background: wheat">
            <div class="rounded h-100 p-4">
                <h6 style="color: #198754;" class="mb-4">Candidate Registration</h6>

                <!-- Display Success Message -->
                @if(session('suc'))
                <div class="alert alert-success">
                    {{ session('suc') }}
                </div>
                @endif

                <!-- Display Error Messages -->
                @if($errors->any())
                <div class="alert alert-danger">
                    <ul>
                        @foreach ($errors->all() as $error)
                            <li>{{ $error }}</li>
                        @endforeach
                    </ul>
                </div>
                @endif

                <form method="POST" action="{{ route('candidates.register') }}" enctype="multipart/form-data">
                    @csrf

                    <!-- Hidden Category ID -->
                    <input type="hidden" name="category_id" value="{{ $category->id }}" />

                    <!-- PDF Upload -->
                    <div class="row mb-3">
                        <div class="col-sm-12">
                            <label for="pdf">Upload PDF</label>
                            <input class="form-control" id="pdf" type="file" name="cvpdf" accept="application/pdf">
                        </div>
                    </div>

                    <!-- Image Upload -->


                    <!-- Submit Button -->
                    <div class="row mb-3">
                        <div class="col-sm-12">
                            <button style="background: #198754; border: none; color: white;" type="submit" class="btn btn-primary">
                                {{ __('Save') }}
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
@include('admin/layouts/includes/footer')
@endsection
