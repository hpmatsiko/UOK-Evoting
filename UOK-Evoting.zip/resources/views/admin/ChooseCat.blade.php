
@extends('user.common')
@section('title', '')
@section('content')

@foreach ($Categories as $Category)
<style type="text/css">
        #sub{
        color: darkblue;
    }
    #subb{
        background: #000000;
    }
</style>
<div class="container-fluid pt-4 px-4" style="margin-top: 6vh">
    <div class="row g-4">

        <a  style="text-decoration: none" class="col-sm-12 col-xl-6" href="{{ route('AddCandidate', $Category->id) }}">
        <div  class="col-sm-12 col-xl-6">
            <div class="rounded h-100 p-4" style="color: black;background: wheat">

            {{ $Category->category }}
            </div>
        </div>

        </a>


    </div>
</div>
@endforeach



@include('admin/layouts/includes/footer')

@endsection
