@extends('admin/layouts.commonA')
@section('title', 'User Registration')
@section('content')
@include('admin/layouts/includes/navA')

<style type="text/css">
    #ibn {
        color: darkblue;
    }
    #ibt {
        background: #000000;
    }

    .section {
        margin-bottom: 30px; /* Space between sections */
    }

    .section h6 {
        color: #198754; /* Section title color */
        margin-bottom: 15px; /* Space below section titles */
    }
</style>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<div class="container-fluid pt-4 px-4">
    <div class="row g-4">
        <div class="col-sm-12 col-xl-12">
            <div class="bg-secondary rounded h-100 p-4">

                {{-- Display Success Message --}}
                @if(session('suc'))
                <div class="alert alert-success">
                    {{ session('suc') }}
                </div>
                @endif

                {{-- Display Validation Errors --}}
                @if ($errors->any())
                <div class="alert alert-danger">
                    <ul>
                        @foreach ($errors->all() as $error)
                        <li>{{ $error }}</li>
                        @endforeach
                    </ul>
                </div>
                @endif

                <form method="POST" action="{{ route('register') }}" enctype="multipart/form-data">
                    @csrf

                    <input type="hidden" name="locale" value="en">
                    @error('locale')
                    <span class="invalid-feedback" role="alert">
                        <strong>{{ $message }}</strong>
                    </span>
                    @enderror

                    <div class="section">
                        <h6>User Information</h6>
                        <div class="row mb-3">
                            <div class="col-xl-6">
                                <input type="text" class="form-control @error('regN') is-invalid @enderror" name="regN" placeholder="Registration Number" value="{{ old('regN') }}" required>
                                @error('regN')
                                <span class="text-danger">{{ $message }}</span>
                                @enderror
                            </div>
                            <div class="col-xl-6">
                                <input type="email" class="form-control @error('email') is-invalid @enderror" name="email" placeholder="Email" value="{{ old('email') }}" required>
                                @error('email')
                                <span class="text-danger">{{ $message }}</span>
                                @enderror
                            </div>
                        </div>

                        <div class="row mb-3">
                            <div class="col-xl-6">
                                <input type="text" class="form-control @error('phone') is-invalid @enderror" name="phone" placeholder="Phone Number" value="{{ old('phone') }}" required>
                                @error('phone')
                                <span class="text-danger">{{ $message }}</span>
                                @enderror
                            </div>
                            <div class="col-xl-6">
                                <input type="password" class="form-control @error('password') is-invalid @enderror" name="password" placeholder="Password" required>
                                @error('password')
                                <span class="text-danger">{{ $message }}</span>
                                @enderror
                            </div>
                        </div>

                        <div class="row mb-3">
                            <div class="col-xl-6">
                                <input type="password" class="form-control @error('password_confirmation') is-invalid @enderror" name="password_confirmation" placeholder="Confirm Password" required>
                                @error('password_confirmation')
                                <span class="text-danger">{{ $message }}</span>
                                @enderror
                            </div>
                            <div class="col-xl-6">
                                <input type="text" class="form-control @error('fname') is-invalid @enderror" name="fname" placeholder="First Name" value="{{ old('fname') }}" required>
                                @error('fname')
                                <span class="text-danger">{{ $message }}</span>
                                @enderror
                            </div>
                        </div>
                    </div>

                    <div class="section">
                        <h6>Additional Information</h6>
                        <div class="row mb-3">
                            <div class="col-xl-6">
                                <input type="text" class="form-control @error('lname') is-invalid @enderror" name="lname" placeholder="Last Name" value="{{ old('lname') }}" required>
                                @error('lname')
                                <span class="text-danger">{{ $message }}</span>
                                @enderror
                            </div>
                            <div class="col-xl-6">
                                <input type="text" class="form-control @error('address') is-invalid @enderror" name="address" placeholder="Address" value="{{ old('address') }}" required>
                                @error('address')
                                <span class="text-danger">{{ $message }}</span>
                                @enderror
                            </div>
                        </div>

                        <div class="row mb-3">
                            <div class="col-xl-6">
                                <input type="date" class="form-control @error('dob') is-invalid @enderror" name="dob" value="{{ old('dob') }}" required>
                                @error('dob')
                                <span class="text-danger">{{ $message }}</span>
                                @enderror
                            </div>
                            <div class="col-xl-6">
                                <input type="text" class="form-control @error('department') is-invalid @enderror" name="department" placeholder="Department" value="{{ old('department') }}" required>
                                @error('department')
                                <span class="text-danger">{{ $message }}</span>
                                @enderror
                            </div>
                        </div>

                        <div class="row mb-3">
                            <div class="col-xl-6">
                                <input type="file" class="form-control @error('image') is-invalid @enderror" name="image" accept="image/*">
                                @error('image')
                                <span class="text-danger">{{ $message }}</span>
                                @enderror
                            </div>
                            <div class="col-xl-6">
                                <select name="gender" class="form-control @error('gender') is-invalid @enderror" required>
                                    <option value="">Select Gender</option>
                                    <option value="Male" {{ old('gender') == 'Male' ? 'selected' : '' }}>Male</option>
                                    <option value="Female" {{ old('gender') == 'Female' ? 'selected' : '' }}>Female</option>
                                    <option value="Others" {{ old('gender') == 'Others' ? 'selected' : '' }}>Others</option>
                                </select>
                                @error('gender')
                                <span class="text-danger">{{ $message }}</span>
                                @enderror
                            </div>
                        </div>

                        <div class="row mb-3">
                            <div class="col-xl-6">
                                <input type="text" class="form-control @error('national_passport_id') is-invalid @enderror" name="national_passport_id" placeholder="National Passport ID" value="{{ old('national_passport_id') }}" required>
                                @error('national_passport_id')
                                <span class="text-danger">{{ $message }}</span>
                                @enderror
                            </div>
                            <div class="col-xl-6">
                                <input type="text" class="form-control @error('specialization') is-invalid @enderror" name="specialization" placeholder="Specialization" value="{{ old('specialization') }}" required>
                                @error('specialization')
                                <span class="text-danger">{{ $message }}</span>
                                @enderror
                            </div>
                        </div>

                        <div class="row mb-3">
                            <div class="col-xl-6">
                                <input type="text" class="form-control @error('program') is-invalid @enderror" name="program" placeholder="Program" value="{{ old('program') }}" required>
                                @error('program')
                                <span class="text-danger">{{ $message }}</span>
                                @enderror
                            </div>
                            <div class="col-xl-6">
                                <input type="text" class="form-control @error('program_mode') is-invalid @enderror" name="program_mode" placeholder="Program Mode" value="{{ old('program_mode') }}" required>
                                @error('program_mode')
                                <span class="text-danger">{{ $message }}</span>
                                @enderror
                            </div>
                        </div>

                        <div class="row mb-3">
                            <div class="col-xl-6">
                                <input type="text" class="form-control @error('intake') is-invalid @enderror" name="intake" placeholder="Intake" value="{{ old('intake') }}" required>
                                @error('intake')
                                <span class="text-danger">{{ $message }}</span>
                                @enderror
                            </div>
                        </div>

                        <div class="row mb-3">
                            <div class="col-xl-6">
                                <select name="marital_status" class="form-control @error('marital_status') is-invalid @enderror" required>
                                    <option value="">Select Marital Status</option>
                                    <option value="Single" {{ old('marital_status') == 'Single' ? 'selected' : '' }}>Single</option>
                                    <option value="Married" {{ old('marital_status') == 'Married' ? 'selected' : '' }}>Married</option>
                                    <option value="Divorced" {{ old('marital_status') == 'Divorced' ? 'selected' : '' }}>Divorced</option>
                                    <option value="Widowed" {{ old('marital_status') == 'Widowed' ? 'selected' : '' }}>Widowed</option>
                                </select>
                                @error('marital_status')
                                <span class="text-danger">{{ $message }}</span>
                                @enderror
                            </div>
                            <div class="col-xl-6">
                                <input type="text" class="form-control @error('nationality') is-invalid @enderror" name="nationality" placeholder="Nationality" value="{{ old('nationality') }}" required>
                                @error('nationality')
                                <span class="text-danger">{{ $message }}</span>
                                @enderror
                            </div>
                        </div>

                        <div class="row mb-3">
                            <div class="col-xl-6">
                                <select name="program_type" class="form-control @error('program_type') is-invalid @enderror" required>
                                    <option value="">Select Program Type</option>
                                    <option value="Full-time" {{ old('program_type') == 'Full-time' ? 'selected' : '' }}>Full-time</option>
                                    <option value="Part-time" {{ old('program_type') == 'Part-time' ? 'selected' : '' }}>Part-time</option>
                                    <option value="Distance Learning" {{ old('program_type') == 'Distance Learning' ? 'selected' : '' }}>Distance Learning</option>
                                </select>
                                @error('program_type')
                                <span class="text-danger">{{ $message }}</span>
                                @enderror
                            </div>
                            <div class="col-xl-6">
                                <select name="usertype" class="form-control @error('usertype') is-invalid @enderror" required>

                                    <option value="voter" {{ old('usertype') == 'voter' ? 'selected' : '' }}>User</option>

                                </select>
                                @error('usertype')
                                <span class="text-danger">{{ $message }}</span>
                                @enderror
                            </div>
                        </div>
                    </div>

                    <button type="submit" class="btn btn-primary">Register</button>
                </form>
            </div>
        </div>
    </div>
</div>

@endsection
