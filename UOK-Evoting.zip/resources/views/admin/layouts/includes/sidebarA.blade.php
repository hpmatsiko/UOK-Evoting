<style type="text/css">
    .nav-link.active {
        color: #198754 !important;
    }
</style>
<!-- Sidebar Start -->
<div class="sidebar pe-4 pb-3">
    <nav class="navbar bg-secondary navbar-dark">
        <a href="{{ route('admin') }}" class="navbar-brand d-flex align-items-center px-4 px-lg-5">
            <h2 class="m-0" style="color:#000066; font-weight: 1000;">
                <img class="" style="height: 10vh; width: 20vh; margin-bottom: 5vh; margin-top: 1vh;" src="/img/logo.png" alt="">
            </h2>
        </a>
        <div class="navbar-nav w-100">
            <a href="{{ route('admin') }}" class="nav-item nav-link {{ Request::routeIs('admin') ? 'active' : '' }}" id="dsh" style="margin-bottom: 1.3vh; padding: 0vh; border-radius: 0vh;">
                <i class="fa fa-tachometer-alt me-2"></i>
                <span id="dash">Dashboard</span>
            </a>


            <div class="nav-item dropdown">
                <a href="#" class="nav-link {{ Request::routeIs('addUser') ? 'active' : '' }}" data-bs-toggle="dropdown" id="ques" style="margin-bottom: 1.3vh; padding: 0vh; border-radius: 0vh;">
                    <i class="fa-solid fa-user me-2"></i>
                    <span id="que">Users</span>
                </a>
                <div class="dropdown-menu bg-transparent border-0">
                    <a href="{{ route('addUser') }}" class="dropdown-item">Add User</a>
                    <a href="UserL" class="dropdown-item">Users List</a>
                </div>

            </div>


            <div class="nav-item dropdown">
                <a href="#" class="nav-link {{ Request::routeIs('addBookCat', 'CatL') ? 'active' : '' }}" data-bs-toggle="dropdown" id="ibt" style="margin-bottom: 1.3vh; padding: 0vh; border-radius: 0vh;">
                    <i class="fa fa-tags me-2"></i>
                    <span id="ibn">Categories</span>
                </a>
                <div class="dropdown-menu bg-transparent border-0">
                    <a href="{{ route('addRun') }}" class="dropdown-item">Add Category</a>
                    <a href="{{ route('CatL') }}" class="dropdown-item">Category List</a>
                </div>
            </div>
            <div class="nav-item dropdown">
                <a href="#" class="nav-link {{ Request::routeIs('ChooseCat', 'SubCatL') ? 'active' : '' }}" data-bs-toggle="dropdown" id="subb" style="margin-bottom: 1.3vh; padding: 0vh; border-radius: 0vh;">
                    <i class="fa fa-tag me-2"></i>
                    <span id="sub">Candidates</span>
                </a>
                <div class="dropdown-menu bg-transparent border-0">

                    <a href="{{ route('CandidateL') }}" class="dropdown-item">Candidate List</a>
                </div>
            </div>






        </div>
    </nav>
</div>
<!-- Sidebar End -->



<script>
    document.addEventListener('DOMContentLoaded', function() {
        const navLinks = document.querySelectorAll('.nav-link');

        navLinks.forEach(link => {
            link.addEventListener('click', function() {
                // Remove 'active' class from all links
                navLinks.forEach(nav => nav.classList.remove('active'));

                // Add 'active' class to the clicked link
                this.classList.add('active');
            });
        });
    });
</script>


