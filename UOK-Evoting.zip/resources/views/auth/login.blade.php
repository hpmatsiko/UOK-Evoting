@extends('layouts.common')
@section('title','Home Page')
@section('content')

<script type="text/javascript">
  function mvh() {
    var hid=document.querySelector('#forg');
    if (hid.style.display=='none') {
      hid.style.display='block';
      document.querySelector('.center2').style.display='none';
    } else {
      hid.style.display='none';
    }
  }
</script>
@php
                                // Generate a random hex color
$randomColor = sprintf('#%06X', mt_rand(0, 0xFFFFFF));
@endphp
<div id="forg" class="d-flex justify-content-center bg-white shadow" style="display: flex; width: 100%;">
  <div class="wow bg-white shadow" data-wow-delay="1.5s" style="position: absolute; top: 25%; padding: 0; border-radius: 2vh; width: 50%;z-index: 900000; ">

    <div class="form_container mt-5">
      @if(session()->has('suc'))
      <!-- Display success message -->
      <div class="alert alert-success">
        {{ session('suc') }}
      </div>
      @endif



      <x-auth-session-status class="mb-4" :status="session('status')" />
      <form name="form" id="register2" action="{{ route('login') }}" method="post">
        @csrf
        <div>
          <div class="form_wrap">
            <div class="form_item mb-3">
              <input id="email" class="form-control" type="text" name="email" :value="old('username')" required autofocus autocomplete="username" placeholder="@lang('messages.email')"/>
              <x-input-error :messages="$errors->get('email')" class="mt-2 btn-danger p-2" />
              </div>
            </div>
            <div class="form_wrap">
              <div class="form_item mb-3">
                <input id="password" class="form-control" type="password" name="password" required autocomplete="current-password" placeholder="@lang('messages.password')"/>
                <x-input-error :messages="$errors->get('password')" class="mt-2 btn-danger p-2" />
                </div>
              </div>
              <div class="btn mt-4">
                <!-- Remember Me -->

                <div class="d-flex justify-content-end mt-4">
                  @if (Route::has('password.request'))
                  <a style="color: black;" class="text-sm text-gray-600 hover:text-gray-900" href="{{ route('password.request') }}">
                    Forgot Password
                  </a>
                  @endif
                  @php
                                // Generate a random hex color
                  $randomColor = sprintf('#%06X', mt_rand(0, 0xFFFFFF));
                  @endphp
                  <button type="submit" class="btn ms-3" style="background:{{ $randomColor }}; border: none; color: black;">
                   Login
                  </button>
                </div>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>

    @endsection
