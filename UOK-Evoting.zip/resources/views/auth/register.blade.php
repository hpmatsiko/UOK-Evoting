@extends('layouts.common')
@section('title', 'Home Page')
@section('content')

<style type="text/css">
  .animate {
    -webkit-animation: animatezoom 0.6s;
    animation: animatezoom 0.6s;
  }

  @-webkit-keyframes animatezoom {
    from { -webkit-transform: scale(0) }
    to { -webkit-transform: scale(1) }
  }

  @keyframes animatezoom {
    from { transform: scale(0) }
    to { transform: scale(1) }
  }
</style>

<script type="text/javascript">
  function mvh() {
    var hid = document.querySelector('#forg');
    hid.style.display = hid.style.display === 'none' ? 'block' : 'none';
    document.querySelector('.center2').style.display = hid.style.display === 'block' ? 'none' : 'flex';
  }
</script>

<div id="forg" style="display: flex; justify-content: center; width: 100%;">
  <div class="wow zoomIn bg-black shadow" data-wow-delay="1.5s" style="z-index: 90000899; position: absolute; top: 30%; background: black; padding: 0vh; border-radius: 2vh; width: 60%;">
    <a href="{{ route('/') }}">
      <div class="cr"><i class="fa-solid fa-xmark"></i></div>
    </a>
    <div class="form_container" style="margin-top: 6vh;">
      <x-auth-session-status class="mb-4" :status="session('status')" />
      <form method="POST" action="{{ route('register') }}" enctype="multipart/form-data">
        @csrf

        <input type="hidden" name="usertype" value="user">

        <div class="form_wrap form_grp">
          <div class="form_item">
            <x-text-input id="regN" class="block mt-1 w-full" type="text" name="regN" :value="old('regN')" required placeholder="{{ __('Registration Number') }}" />
            <x-input-error :messages="$errors->get('regN')" class="mt-2" />
          </div>

          <div class="form_item">
            <x-text-input id="email" class="block mt-1 w-full" type="email" name="email" :value="old('email')" required autocomplete="email" placeholder="{{ __('messages.email') }}" />
            <x-input-error :messages="$errors->get('email')" class="mt-2" />
          </div>
        </div>

        <div class="form_wrap form_grp">
          <div class="form_item">
            <input id="phone" type="text" name="phone" value="{{ old('phone') }}" required placeholder="{{ __('messages.phone') }}" />
            <x-input-error :messages="$errors->get('phone')" class="mt-2" />
          </div>

          <div class="form_item">
            <x-text-input id="password" class="block mt-1 w-full" type="password" name="password" required autocomplete="new-password" placeholder="{{ __('messages.password') }}" />
            <x-input-error :messages="$errors->get('password')" class="mt-2" />
          </div>
        </div>

        <div class="form_wrap form_grp">
          <div class="form_item">
            <x-text-input id="password_confirmation" class="block mt-1 w-full" type="password" name="password_confirmation" required autocomplete="new-password" placeholder="{{ __('messages.confirm_password') }}" />
            <x-input-error :messages="$errors->get('password_confirmation')" class="mt-2" />
          </div>
        </div>

        <div class="form_wrap form_grp">
          <div class="form_item">
            <input id="fname" type="text" name="fname" value="{{ old('fname') }}" required placeholder="{{ __('messages.fname') }}" />
            <x-input-error :messages="$errors->get('fname')" class="mt-2" />
          </div>

          <div class="form_item">
            <input id="lname" type="text" name="lname" value="{{ old('lname') }}" required placeholder="{{ __('messages.lname') }}" />
            <x-input-error :messages="$errors->get('lname')" class="mt-2" />
          </div>
        </div>

        <div class="form_wrap form_grp">
          <div class="form_item">
            <input id="address" type="text" name="address" value="{{ old('address') }}" required placeholder="{{ __('Address') }}" />
            <x-input-error :messages="$errors->get('address')" class="mt-2" />
          </div>

          <div class="form_item">
            <input id="dob" type="date" name="dob" value="{{ old('dob') }}" required />
            <x-input-error :messages="$errors->get('dob')" class="mt-2" />
          </div>
        </div>

        <div class="form_wrap form_grp">
          <div class="form_item">
            <input id="department" type="text" name="department" value="{{ old('department') }}" required placeholder="{{ __('Department') }}" />
            <x-input-error :messages="$errors->get('department')" class="mt-2" />
          </div>

          <div class="form_item">
            <select name="gender" required>
              <option value="">{{ __('messages.gender') }}</option>
              <option value="Male">{{ __('messages.male') }}</option>
              <option value="Female">{{ __('messages.female') }}</option>
              <option value="Others">{{ __('messages.others') }}</option>
            </select>
            <x-input-error :messages="$errors->get('gender')" class="mt-2" />
          </div>
        </div>

        <div class="form_wrap form_grp">
          <div class="form_item">
            <select name="martial_status" required>
              <option value="">{{ __('Martial Status') }}</option>
              <option value="Single">Single</option>
              <option value="Married">Married</option>
              <option value="Divorced">Divorced</option>
              <option value="Widowed">Widowed</option>
            </select>
            <x-input-error :messages="$errors->get('martial_status')" class="mt-2" />
          </div>

          <div class="form_item">
            <input id="nationality" type="text" name="nationality" value="{{ old('nationality') }}" required placeholder="{{ __('Nationality') }}" />
            <x-input-error :messages="$errors->get('nationality')" class="mt-2" />
          </div>
        </div>

        <div class="form_wrap form_grp">
          <div class="form_item">
            <input id="national_passport_id" type="text" name="national_passport_id" value="{{ old('national_passport_id') }}" required placeholder="{{ __('National Passport ID') }}" />
            <x-input-error :messages="$errors->get('national_passport_id')" class="mt-2" />
          </div>

          <div class="form_item">
            <input id="image" type="file" name="image" accept="image/*" />
            <x-input-error :messages="$errors->get('image')" class="mt-2" />
          </div>
        </div>

        <div class="form_wrap form_grp">
          <div class="form_item">
            <input id="program_type" type="text" name="program_type" value="{{ old('program_type') }}" required placeholder="{{ __('Program Type') }}" />
            <x-input-error :messages="$errors->get('program_type')" class="mt-2" />
          </div>

          <div class="form_item">
            <input id="specialization" type="text" name="specialization" value="{{ old('specialization') }}" required placeholder="{{ __('Specialization') }}" />
            <x-input-error :messages="$errors->get('specialization')" class="mt-2" />
          </div>
        </div>

        <div class="form_wrap form_grp">
          <div class="form_item">
            <input id="program" type="text" name="program" value="{{ old('program') }}" required placeholder="{{ __('Program') }}" />
            <x-input-error :messages="$errors->get('program')" class="mt-2" />
          </div>

          <div class="form_item">
            <input id="program_mode" type="text" name="program_mode" value="{{ old('program_mode') }}" required placeholder="{{ __('Program Mode') }}" />
            <x-input-error :messages="$errors->get('program_mode')" class="mt-2" />
          </div>
        </div>

        <div class="form_wrap form_grp">
          <div class="form_item">
            <input id="intake" type="text" name="intake" value="{{ old('intake') }}" required placeholder="{{ __('Intake') }}" />
            <x-input-error :messages="$errors->get('intake')" class="mt-2" />
          </div>
        </div>

        <div class="form_wrap form_grp">
          <div class="form_item">
            <center>
              <a style="color: #06BBCC;" href="{{ route('login') }}">
                {{ __('messages.already_registered') }}
              </a>
              <button type="submit" style="background: #06BBCC; border: none; color: black; padding: 1.5vh; border-radius: 1vh;">
                {{ __('messages.Register') }}
              </button>
            </center>
          </div>
        </div>
      </form>
    </div>
  </div>
</div>

@endsection
