<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Models\BookCategoryModel;
use App\Models\RunningToBe;
use App\Models\SubCategoryModel;
use App\Models\BookModel;
use App\Models\ChapterModel;
use App\Models\NoteModel;
use App\Models\ExerciseModel;
use App\Models\ContentModel;
use App\Models\LevelModel;

class CatController extends Controller
{


    public function saveCat(Request $request)
    {
        $validatedData = $request->validate([
            'title' => 'required|string|max:255', // Example validation rule for the title field
        ]);

        $data = new RunningToBe();
        $data->category = $request->title;
        $data->locale = $request->locale;
        $data->save();
        return redirect()->back()->with('suc', 'Done');
    }
}
