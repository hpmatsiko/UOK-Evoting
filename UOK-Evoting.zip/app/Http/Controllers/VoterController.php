<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Mail\RegnCodeMail;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Str;
use App\Models\RegnCode;
use App\Models\User;
use App\Models\Candidates;
use App\Models\Vote;

class VoterController extends Controller
{
    public function key(Request $request)
    {
        // Get the authenticated user
        $user = Auth::user();
        $authRegN = $user->regN;

        // Check if the user already has an entry in regn_codes table
        $existingCode = RegnCode::where('user_id', $user->id)->first();

        if ($existingCode) {
            // User already has a generated code
            return redirect()->back()->with('message', 'You have already requested a voting key.');
        }

        // Get the inputted regN from the request
        $inputRegN = $request->input('regN');

        // Compare the inputted regN with the authenticated user's regN
        if ($authRegN === $inputRegN) {
            // Retrieve the user's email
            $email = $user->email;

            // Generate a random number and concatenate with regN
            $randomNumber = Str::random(6);  // Generates a random 6-character string
            $generatedCode = $randomNumber . $authRegN;

            // Save the generated code to the database along with user_id
            RegnCode::create([
                'user_id' => $user->id,     // Save the user ID
                'regN' => $authRegN,
                'generated_code' => $generatedCode,
            ]);

            // Send the HTML email using the mailable
            Mail::to($email)->send(new RegnCodeMail($generatedCode, $user));

            // Return success message
            $message = "The inputted regN matches, and the code has been sent to your email.";
        } else {
            // Return error message if regN does not match
            $message = "The inputted regN does not match.";
        }

        // Redirect back with the success or error message
        return redirect()->back()->with('message', $message);
    }


    public function showVoteForm($candidate_id)
    {
        // Retrieve the candidate based on the provided ID
        $candidate = Candidates::findOrFail($candidate_id);
        return view('user.vote', compact('candidate'));
    }

    public function submitVote(Request $request)
    {
        $request->validate([
            'candidate_id' => 'required|exists:candidates,id',
            'generated_code' => 'required',
            'category_id' => 'required',
        ]);

        // Check if the registration code exists
        $regnCodeExists = RegnCode::where('generated_code', $request->generated_code)->exists();

        if (!$regnCodeExists) {
            // Redirect back with an error message if the code does not exist
            return redirect()->back()->withInput()->withErrors(['generated_code' => 'Voting key code does not exist.']);
        }
        $user = Auth::user();
        // Check if the user has already voted for this candidate
        $hasVoted = Vote::where('user_id', $user->id) // Corrected here
            ->where('category_id', $request->category_id)
            ->exists();

        if ($hasVoted) {
            return redirect()->back()->withErrors(['vote' => 'You have already voted for this candidate.']);
        }

        // Save the vote to the database
        Vote::create([
            'user_id' => $user->id,
            'candidate_id' => $request->candidate_id,
            'category_id' => $request->category_id,
            'generated_code' => $request->generated_code,
        ]);

        // Optionally, increment the votes for the candidate
        $candidate = Candidates::find($request->candidate_id); // Assuming your model is named Candidate
        $candidate->increment('votes');

        return redirect()->back()->with('suc', 'Vote submitted successfully!');
    }
}
