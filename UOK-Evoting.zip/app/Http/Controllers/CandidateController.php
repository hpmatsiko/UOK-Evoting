<?php

namespace App\Http\Controllers;

use App\Models\Candidates;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Log;
use Illuminate\Validation\ValidationException;

class CandidateController extends Controller
{
    /**
     * Handle an incoming candidate registration request.
     *
     * @throws ValidationException
     */
    public function candidateRegister(Request $request)
    {
        // Validate the request
        $request->validate([
            'category_id' => 'required|exists:running_to_be_models,id', // Ensure category_id exists
            'cvpdf' => 'nullable|file|mimes:pdf|max:9048', // Max size of 9MB

        ]);

        // Check if at least one file is uploaded
        if (!$request->hasFile('cvpdf') && !$request->hasFile('image')) {
            return redirect()->back()->withErrors(['file_upload' => 'Either CV or Image must be uploaded.']);
        }

        // Handle file upload for CV PDF
        $cvPath = null; // Initialize CV path variable
        if ($request->hasFile('cvpdf')) {
            try {
                // Save the CV in the 'cvs' directory and store the full path
                $cvPath = $request->file('cvpdf')->move(public_path('cvs'), $request->file('cvpdf')->getClientOriginalName());
            } catch (\Exception $e) {
                Log::error('CV file upload error: ' . $e->getMessage());
                return redirect()->back()->withErrors(['file_upload' => 'There was an error uploading the CV file.']);
            }
        }



        // Create the candidate
        Candidates::create([
            'category_id' => $request->category_id,
            'user_id' => Auth::id(), // Get the currently authenticated user
            'cvpdf' => $cvPath ? basename($cvPath) : null,
            'votes' => 0, // Save the base name of the uploaded CV PDF

        ]);

        return redirect()->back()->with('suc', 'Candidate registered successfully!');
    }


    public function confirm($id)
    {
        $candidate = Candidates::findOrFail($id);
        // Assuming you have a status field in your candidates table
        $candidate->status = 'confirmed'; // Update the status
        $candidate->save();

        return redirect()->back()->with('success', 'Candidate confirmed successfully.');
    }

    public function reject($id)
    {
        $candidate = Candidates::findOrFail($id);
        // Assuming you have a status field in your candidates table
        $candidate->status = 'rejected'; // Update the status
        $candidate->save();

        return redirect()->back()->with('success', 'Candidate rejected successfully.');
    }
}