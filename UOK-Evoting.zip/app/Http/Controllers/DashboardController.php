<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Vote;
use App\Models\Candidates;
use App\Models\User;
use App\Models\RunningToBe;
use Illuminate\Support\Facades\DB;

use Illuminate\Support\Facades\Auth;

class DashboardController extends Controller
{


    public function index()
    {

        return view('admin.dashboard');
    }

    public function userd()
    {
        // Fetch confirmed candidates with their votes and paginate the result
        $candidates = Candidates::withCount('votes')
            ->where('status', 'confirmed') // Filter candidates by status
            ->paginate(10); // Adjust the number as needed

        // Calculate total votes for percentage calculations
        $totalVotes = Vote::count();

        // Group candidates by category
        $groupedCandidates = $candidates->groupBy('category_id');

        // Calculate votes percentage
        foreach ($groupedCandidates as $categoryId => $grouped) {
            foreach ($grouped as $candidate) {
                // Avoid division by zero
                if ($totalVotes > 0) {
                    $candidate->votes_percentage = ($candidate->votes_count / $totalVotes) * 100;
                } else {
                    $candidate->votes_percentage = 0; // No votes cast
                }
            }
        }

        return view('dashboard', [
            'groupedCandidates' => $groupedCandidates,
            'candidates' => $candidates,
        ]);
    }




    public function vk()
    {

        return view('user.vk');
    }


    public function ChooseCat()
    {

        $Categories = RunningToBe::all();
        // Pass the data to a view
        return view('admin.ChooseCat', compact('Categories'));
    }



    public function CatL()
    {

        $Categories = RunningToBe::all();
        // Pass the data to a view
        return view('admin.CategoryL', compact('Categories'));
    }

    // In UserController.php

    public function UserL()
    {
        $users = User::paginate(5); // Fetch all users from the database
        return view('admin.UserL', compact('users')); // Change the view name as needed
    }


    public function addRun()
    {
        return view('admin/AddRun');
    }

    public function addCandidate(RunningToBe $category)
    {
        return view('admin/AddCandidate', compact('category'));
    }

    public function addUser()
    {

        return view('admin/addUser');
    }


    public function CandidateL()
    {
        $candidates = Candidates::with(['user', 'category'])->paginate(3); // Eager load user and category relationships
        return view('admin.candidate_list', compact('candidates'));
    }
}
