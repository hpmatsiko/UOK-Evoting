<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Auth\Events\Registered;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\ValidationException;
use Illuminate\View\View;
use Illuminate\Support\Facades\Log;

class RegisteredUserController extends Controller
{
    /**
     * Display the registration view.
     */
    public function create(): View
    {
        return view('auth.register');
    }

    /**
     * Handle an incoming registration request.
     *
     * @throws ValidationException
     */
    public function store(Request $request): RedirectResponse
    {
        // Validate the request including the new fields
        $request->validate([
            'regN' => 'required|string|max:255|unique:users',
            'email' => 'required|string|email|max:255|unique:users',
            'phone' => 'required|string|max:255|unique:users', // Ensure phone is unique
            'password' => 'required|string|min:8|confirmed',
            'fname' => 'required|string|max:255',
            'lname' => 'required|string|max:255',
            'address' => 'required|string|max:255',
            'dob' => 'required|date',
            'department' => 'required|string',
            'image' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:2048',
            'gender' => 'required|string',
            'usertype' => 'required|string',
            'marital_status' => 'required|string',
            'nationality' => 'required|string',
            'national_passport_id' => 'required|string',
            'program_type' => 'required|string',
            'specialization' => 'required|string',
            'program' => 'required|string',
            'program_mode' => 'required|string',
            'intake' => 'required|string',
        ]);
        // Handle image upload if exists
        $imageName = null; // Initialize image name variable
        if ($request->hasFile('image')) {
            try {
                // Get the image name
                $imageName = time() . '_' . $request->file('image')->getClientOriginalName(); // Generate a unique name

                // Move the image to the 'images' directory
                $request->file('image')->move(public_path('images'), $imageName);
            } catch (\Exception $e) {
                Log::error('Image file upload error: ' . $e->getMessage());
                return redirect()->back()->withErrors(['file_upload' => 'There was an error uploading the image.']);
            }
        }
        // Create the user
        $user = User::create([
            'regN' => $request->regN,
            'email' => $request->email,
            'phone' => $request->phone,
            'password' => Hash::make($request->password),
            'fname' => $request->fname,
            'lname' => $request->lname,
            'address' => $request->address,
            'dob' => $request->dob,
            'department' => $request->department,
            'gender' => $request->gender,
            'usertype' => $request->usertype,
            'marital_status' => $request->martial_status,
            'nationality' => $request->nationality,
            'national_passport_id' => $request->national_passport_id,
            'program_type' => $request->program_type,
            'specialization' => $request->specialization,
            'program' => $request->program,
            'program_mode' => $request->program_mode,
            'intake' => $request->intake,
            'image' => $imageName,
        ]);




        event(new Registered($user));

        Auth::login($user);

        return redirect(route('verification.notice', absolute: false));
    }

    /**
     * Destroy an authenticated session.
     */
    public function destroy(Request $request): RedirectResponse
    {
        Auth::guard('web')->logout();

        $request->session()->invalidate();

        $request->session()->regenerateToken();

        return redirect('/');
    }
}
