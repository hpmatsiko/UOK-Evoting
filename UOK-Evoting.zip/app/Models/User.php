<?php

namespace App\Models;

use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;

class User extends Authenticatable implements MustVerifyEmail
{
    use HasFactory, Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'email',
        'password',
        'phone',
        'fname',
        'lname',
        'gender',
        'usertype',
        'address',
        'image',
        'regN',
        'dob',
        'department',
        'marital_status',
        'nationality',
        'national_passport_id',
        'program_type',
        'specialization',
        'program',
        'program_mode',
        'intake',
    ];

    /**
     * The attributes that should be hidden for serialization.
     *
     * @var array<int, string>
     */
    protected $hidden = [
        'password',
        'remember_token',
    ];

    /**
     * The attributes that should be cast.
     *
     * @return array<string, string>
     */
    protected function casts(): array
    {
        return [
            'email_verified_at' => 'datetime',
            'password' => 'hashed',
        ];
    }

    // Relationship with candidates
    public function candidates()
    {
        return $this->hasMany(Candidates::class);
    }

    // Optional: If a user can belong to a specific RunningToBe category
    public function runningToBe()
    {
        return $this->belongsTo(RunningToBe::class, 'category_id');
    }
}
