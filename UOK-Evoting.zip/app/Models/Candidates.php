<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Candidates extends Model
{
    use HasFactory;

    protected $fillable = ['category_id', 'user_id', 'cvpdf', 'votes', 'status'];
    protected $table = 'candidates';


    // Relationship with user
    public function user()
    {
        return $this->belongsTo(User::class);
    }

    // Relationship with RunningToBe
    public function category()
    {
        return $this->belongsTo(RunningToBe::class, 'category_id');
    }

    public function votes()
    {
        return $this->hasMany(Vote::class, 'candidate_id'); // Use 'candidate_id' here
    }
}