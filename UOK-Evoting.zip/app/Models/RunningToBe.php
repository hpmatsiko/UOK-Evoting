<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class RunningToBe extends Model
{
    use HasFactory;
    protected $fillable = ['category', 'locale'];
    protected $table = 'running_to_be_models';

    // Relationship with candidates
    public function candidates()
    {
        return $this->hasMany(Candidates::class);
    }
}
