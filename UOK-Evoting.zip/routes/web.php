<?php

use App\Http\Controllers\ProfileController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\CatController;
use App\Http\Controllers\CandidateController;


use App\Http\Controllers\VoterController;
use App\Models\RunningToBe;
use Illuminate\Support\Facades\Route;


Route::middleware('auth', 'admin', 'verified')->group(function () {
    Route::get('/admin/dashboard', [DashboardController::class, 'index'])->name('admin');
    Route::get('/admin/addRun', [DashboardController::class, 'addRun'])->name('addRun');

    Route::post('/admin/save-Cat', [CatController::class, 'saveCat'])->name('save.Cat');
    Route::post('/admin/save-cat', [CatController::class, 'saveCat'])->name('save.category');
    Route::post('/admin/saveSubCat', [CatController::class, 'saveSubCat'])->name('saveSubCat');

    Route::get('/admin/CatL', [DashboardController::class, 'CatL'])->name('CatL');

    Route::delete('/category/{id}', [RunningToBe::class, 'destroy'])->name('destroyC');

    Route::get('/Cats/UpdateCat/{cat}', [DashboardController::class, 'UpdateCat'])->name('UpdateCat');
    Route::put('/Cats/UpdateCat/{cat}', [CatController::class, 'UpdateCat'])->name('UpdateCat');
    Route::put('/Cats/UpdateSubCat/{subcat}', [CatController::class, 'UpdateSubCat'])->name('UpdateSubCat');
    Route::get('/Cats/UpdateSubCat/{subcat}', [DashboardController::class, 'UpdateSubCat'])->name('UpdateSubCat');
    Route::get('/admin/addUser', [DashboardController::class, 'addUser'])->name('addUser');
    Route::get('/admin/UserL', [DashboardController::class, 'UserL'])->name('UserL');
    Route::get('/admin/candidates', [DashboardController::class, 'CandidateL'])->name('CandidateL');

    Route::post('/candidates/confirm/{id}', [CandidateController::class, 'confirm'])->name('candidates.confirm');
    Route::post('/candidates/reject/{id}', [CandidateController::class, 'reject'])->name('candidates.reject');
});






Route::middleware('auth', 'voter', 'verified')->group(function () {
    Route::get('/user/dashboard', [DashboardController::class, 'userd'])->name('user');
    Route::get('/user/vk', [DashboardController::class, 'vk'])->name('vk');
    Route::post('/user/key', [VoterController::class, 'key'])->name('key');
    Route::get('/viewCat/{Cat}', [HomeController::class, 'viewCat'])->name('viewCat');
    Route::get('/viewCatT/{chapter}', [HomeController::class, 'viewCatT'])->name('viewCatT');
    Route::get('/categories/{category}', [DashboardController::class, 'showu'])->name('showu');
    Route::get('/vote/{candidate_id}', [VoterController::class, 'showVoteForm'])->name('vote.form');
    Route::post('/vote', [VoterController::class, 'submitVote'])->name('vote.submit');
    Route::get('/admin/ChooseCat', [DashboardController::class, 'ChooseCat'])->name('ChooseCat');
    Route::get('/admin/AddCandidate/{category}', [DashboardController::class, 'AddCandidate'])->name('AddCandidate');
    Route::post('/candidates/register', [CandidateController::class, 'candidateRegister'])->name('candidates.register');
});


Route::get('/', [HomeController::class, 'index'])->name('/');
Route::get("search", [CatController::class, 'search'])->name('search');
Route::get('/categoriesView/{category}', [HomeController::class, 'show'])->name('categories.show');

Route::middleware('auth')->group(function () {
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
});

require __DIR__ . '/auth.php';