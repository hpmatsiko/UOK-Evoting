<style type="text/css" media="screen">
   .ourschools
   {
    width: 170vh;
    display:flex;
    justify-content: space-around;
    padding:7vh;
}

</style>
<div>

    <div class="ourschools">

        <!-- Add your preferred icon library (e.g., Font Awesome) -->
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">

        <div class="nav-item dropdown wow fadeInUp">
            <a style="background:#fff;color: black; font-size: 18px;padding: 0;" href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown"><?php echo app('translator')->get('messages.school_category'); ?></a>
            <div class="dropdown-menu fade-down m-0 wow fadeInUp">
                <?php $__currentLoopData = $bookCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bookCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                <a class="dropdown-item" href="<?php echo e(route('showu', $bookCategory->id)); ?>"><?php echo e($bookCategory->book_category); ?></a>
                
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>


        <div class="nav-item dropdown wow fadeInUp">
            <a style="background:#fff;color: black; font-size: 18px;padding: 0;" href="#" class="nav-link" data-bs-toggle="dropdown"> <div class="search-input-caret-jump wow fadeInUp" data-wow-delay="0.5s" style=" font-size: 18px;">
              <input type="text" name="search" id="search" placeholder="<?php echo app('translator')->get('messages.search_book'); ?>" class="form-control" onfocus="this.value=''" style="padding: 0;">
              <button><i class="fas fa-search"></i></button>
          </div></a>
          <div id="search_list" class="dropdown-menu fade-down m-0 wow fadeInUp">

        </div>
    </div>


    <div>

        <div class="nav-item dropdown wow fadeInUp" data-wow-delay="0.6s">
           <div style="display: flex;justify-content: center;align-items: center;">

              <a style="background:#fff;color: black; font-size: 18px;padding: 0;" href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown"><i  style="font-size:;margin-right: 1vh;" class="fa-solid fa-globe i"></i><?php echo app('translator')->get('messages.Language'); ?></a>
           </div> 
           <div class="dropdown-menu fade-down m-0 wow fadeInUp">
            <a href="<?php echo e(route('locale', ['locale' => 'en'])); ?>" class="dropdown-item"><?php echo app('translator')->get('messages.English'); ?></a>
            <a href="<?php echo e(route('locale', ['locale' => 'fr'])); ?>" class="dropdown-item"><?php echo app('translator')->get('messages.French'); ?></a>
            <a href="<?php echo e(route('locale', ['locale' => 'kin'])); ?>" class="dropdown-item"><?php echo app('translator')->get('messages.Kinyarwanda'); ?></a>

        </div>
    </div> 
</div>
 <div class="nav-item dropdown wow fadeInUp" data-wow-delay="0.6s">
           <div style="display: flex;justify-content: center;align-items: center;">

               <a style="background:#fff;color: black; font-size: 18px;padding: 0;margin-right: 3vh;word-spacing: 0.5vh;" href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown"><?php echo e(Auth::user()->fname); ?> <?php echo e(Auth::user()->lname); ?></a>
           </div> 
           <div class="dropdown-menu fade-down m-0 wow fadeInUp">
             <?php if (isset($component)) { $__componentOriginald69b52d99510f1e7cd3d80070b28ca18 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald69b52d99510f1e7cd3d80070b28ca18 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.responsive-nav-link','data' => ['href' => route('profile.edit')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('responsive-nav-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('profile.edit'))]); ?>
                    <?php echo e(__('messages.my_account')); ?>

                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald69b52d99510f1e7cd3d80070b28ca18)): ?>
<?php $attributes = $__attributesOriginald69b52d99510f1e7cd3d80070b28ca18; ?>
<?php unset($__attributesOriginald69b52d99510f1e7cd3d80070b28ca18); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald69b52d99510f1e7cd3d80070b28ca18)): ?>
<?php $component = $__componentOriginald69b52d99510f1e7cd3d80070b28ca18; ?>
<?php unset($__componentOriginald69b52d99510f1e7cd3d80070b28ca18); ?>
<?php endif; ?>
             <form method="POST" action="<?php echo e(route('logout')); ?>">
                    <?php echo csrf_field(); ?>

                    <?php if (isset($component)) { $__componentOriginald69b52d99510f1e7cd3d80070b28ca18 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald69b52d99510f1e7cd3d80070b28ca18 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.responsive-nav-link','data' => ['href' => route('logout'),'onclick' => 'event.preventDefault();
                                        this.closest(\'form\').submit();']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('responsive-nav-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('logout')),'onclick' => 'event.preventDefault();
                                        this.closest(\'form\').submit();']); ?>
                        <?php echo e(__('messages.logout')); ?>

                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald69b52d99510f1e7cd3d80070b28ca18)): ?>
<?php $attributes = $__attributesOriginald69b52d99510f1e7cd3d80070b28ca18; ?>
<?php unset($__attributesOriginald69b52d99510f1e7cd3d80070b28ca18); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald69b52d99510f1e7cd3d80070b28ca18)): ?>
<?php $component = $__componentOriginald69b52d99510f1e7cd3d80070b28ca18; ?>
<?php unset($__componentOriginald69b52d99510f1e7cd3d80070b28ca18); ?>
<?php endif; ?>
                </form>
           
        </div>
    </div> 
</div>

</div><?php /**PATH C:\Users\HP Matsiko\hod\resources\views/user/includes/ourschool.blade.php ENDPATH**/ ?>