
<?php $__env->startSection('title', 'Add Book Category'); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('admin/layouts/includes/navA', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<style type="text/css">
    #ibn{
        color: darkblue;
    } 
    #ibt{
        background: #000000;
    } 
</style>
<style>
    table {
        width: 100%;
        border-collapse: collapse;
    }
    th, td {
        border: 1px solid #dddddd;
        text-align: left;
        padding: 8px;
    }
    th {
        background-color: #f2f2f2;
    }

    /* Modal styles */
    .modal {
        display: none; 
        position: fixed; 
        z-index: 1; 
        padding-top: 100px; 
        left: 0;
        top: 0;
        width: 100%;
        height: 100%;
        overflow: auto; 
        background-color: rgb(0,0,0); 
        background-color: rgba(0,0,0,0.4); 
    }

    .modal-content {
        background-color: #fefefe;
        margin: auto;
        padding: 20px;
        border: 1px solid #888;
        width: 80%;
    }

    .close {
        color: #aaa;
        float: right;
        font-size: 28px;
        font-weight: bold;
    }

    .close:hover,
    .close:focus {
        color: black;
        text-decoration: none;
        cursor: pointer;
    }
</style>
<div class="container-fluid pt-4 px-4">
    <div class="row g-4">
        <div class="col-sm-12 col-xl-12">
          <div class="col-12">
            <div class="bg-secondary rounded h-100 p-4">
                <?php if(session('suc')): ?>
                <div class="alert alert-success"><?php echo e(session('suc')); ?></div>
                <?php endif; ?>
                <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
                <?php endif; ?>
                <h6 style="color: darkgrey;" class="mb-4">Book Category List</h6>
                <div class="table-responsive">
                    <?php if($teachers->isEmpty()): ?>
                    <div class="container-fluid pt-4 px-4">
                        <div class="row g-4">


                            <div class="col-sm-12 col-xl-6">
                                <div class="bg-secondary rounded h-100 p-4" style="color: darkgrey;">

                                    <p>No any category found </p>
                                </div>
                            </div>




                        </div>
                    </div>
                    <?php endif; ?>


                        
                        


                            <table>
                                <thead>
                                    <tr>
                                        <th>Teacher Name</th>
                                        <th>Courses</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                 <?php $__currentLoopData = $teachers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $teacher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                 <?php if(isset($teacher->courses) && $teacher->courses->isNotEmpty()): ?>
                                 <tr>
                                    <td><?php echo e($teacher->fname); ?></td>
                                    <td>
                                          <ul>
                                    <?php $__currentLoopData = $teacher->courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php
                                            $level = \App\Models\LevelModel::whereIn('id', [$course->level_id])->first();
                                        ?>
                                        <li>
                                            <?php if($level): ?>
                                                <?php echo e($level->level); ?> - <?php echo e($course->bname); ?>

                                            <?php else: ?>
                                                Level not found - <?php echo e($course->bname); ?>

                                            <?php endif; ?>
                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                                        </td>
                                        <td>
                                            <?php $__currentLoopData = $teacher->courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <a href="<?php echo e(url('/update-course/' . $teacher->id . '/' . $course->id)); ?>">Update</a> |
                                            <a href="#" class="delete-link" data-teacher-id="<?php echo e($teacher->id); ?>" data-course-id="<?php echo e($course->id); ?>" data-course-name="<?php echo e($course->bname); ?>" data-teacher-name="<?php echo e($teacher->fname); ?>">Delete</a><br><br>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </td>
                                    </tr>
                                    <?php endif; ?>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>

    <!-- The Modal -->
    <div id="deleteModal" class="modal">
        <div class="modal-content">
            <span class="close">&times;</span>
            <form id="deleteForm" action="/delete-course" method="POST">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="teacher_id" id="teacher_id">
                <input type="hidden" name="course_id" id="course_id">

                <p id="deleteMessage"></p>
                <button type="submit">Delete Course</button>
            </form>
        </div>
    </div>

    <script>
        // Get the modal
        var modal = document.getElementById("deleteModal");

        // Get the <span> element that closes the modal
        var span = document.getElementsByClassName("close")[0];

        // When the user clicks on <span> (x), close the modal
        span.onclick = function() {
            modal.style.display = "none";
        }

        // When the user clicks anywhere outside of the modal, close it
        window.onclick = function(event) {
            if (event.target == modal) {
                modal.style.display = "none";
            }
        }

        // Get all delete links
        var deleteLinks = document.querySelectorAll('.delete-link');

        deleteLinks.forEach(function(link) {
            link.onclick = function() {
                var teacherId = this.getAttribute('data-teacher-id');
                var courseId = this.getAttribute('data-course-id');
                var courseName = this.getAttribute('data-course-name');
                var teacherName = this.getAttribute('data-teacher-name');

                // Set form values
                document.getElementById('teacher_id').value = teacherId;
                document.getElementById('course_id').value = courseId;
                document.getElementById('deleteMessage').innerText = 'Are you sure you want to delete the course "' + courseName + '" for teacher "' + teacherName + '"?';

                // Display the modal
                modal.style.display = "block";
            }
        });
    </script>
    <?php echo $__env->make('admin/layouts/includes/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 

    <?php $__env->stopSection(); ?>

<?php echo $__env->make('admin/layouts.commonA', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP Matsiko\hod\resources\views/admin/TeacherCourseL.blade.php ENDPATH**/ ?>