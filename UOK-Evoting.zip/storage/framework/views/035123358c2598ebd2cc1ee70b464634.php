
<?php $__env->startSection('title', 'Add Book Category'); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('admin/layouts/includes/nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<style type="text/css">
        #ex{
        color: darkblue;
    } 
    #exer{
        background: #000000;
    } 
</style>
<div class="container-fluid pt-4 px-4">
    <div class="row g-4">
        <div class="col-sm-12 col-xl-12">
          <div class="col-12">
            <div class="bg-secondary rounded h-100 p-4">
                <h6 style="color: darkgrey;" class="mb-4">Exercises List</h6>
                <div class="table-responsive">
                    <?php if($exercises->isEmpty()): ?>
                    <div class="container-fluid pt-4 px-4">
                        <div class="row g-4">


                            <div class="col-sm-12 col-xl-6">
                                <div class="bg-secondary rounded h-100 p-4" style="color: darkgrey;">

                                    <p>No any exercise found </p>
                                </div>
                            </div>




                        </div>
                    </div>
                    <?php endif; ?>


                    <table class="table">
                        <thead>
                            <tr>
                                <th scope="col">#</th>

                                <th>Exercise Name</th>
                                <th scope="col">Action</th>
                                

                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $exercises; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $exercise): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            

                            <tr>
                                <th scope="row"><?php echo e($index + 1); ?></th>
                                <th scope="row"><?php echo e($exercise->ex); ?></th>
                               
                                <td> <a href="<?php echo e(route('UpdateEx',$exercise->id)); ?>" class="btn btn-success btn-sm" style="margin-right: 2vh;color: darkgrey;">Edit</a><a href="" class="btn btn-danger btn-sm" style="color: darkgrey;">Remove</a></td>

                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                        </tbody>
                    </table>


                </div>
            </div>
        </div>

    </div>
</div>
</div>
<?php echo $__env->make('admin/layouts/includes/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin/layouts.common', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP Matsiko\new\resources\views/admin/ExL.blade.php ENDPATH**/ ?>