
<?php $__env->startSection('title','Home Page'); ?>
<?php $__env->startSection('content'); ?>

<div class="container-xxl py-5">
    <div class="container">
        <div style="display: flex;justify-content: space-around;" class="row g-4">
<h1><?php echo e($category->book_category); ?></h1>

<?php if($subcategories->isEmpty()): ?>
    <p>No subcategories found in this category.</p>
<?php else: ?>
    <?php $__currentLoopData = $subcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
     <div class="col-lg-4 col-sm-12 wow fadeInUp" data-wow-delay="0.7s" style="word-break: break-all;">
             <div class="service-item text-center pt-3" >
                <div class="p-4" style="text-align: left;">
        <h2><?php echo e($subcategory->sub_category); ?></h2>
        <?php
            $subcategoryBooks = $books->where('sub_category_id', $subcategory->id);
        ?>
        <?php if($subcategoryBooks->isEmpty()): ?>
            <p>No books found in this subcategory.</p>
        <?php else: ?>
            <ul>
                <?php $__currentLoopData = $subcategoryBooks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a class="boh" href="<?php echo e(route("login")); ?>" style="padding: 4vh;"><li>
                        <?php echo e($book->bname); ?>

                       
                        <?php if($book->image): ?>
                            <img src="<?php echo e(asset('bookImages/' . $book->image)); ?>" alt="Book Image" width="100">
                        <?php endif; ?>
                    </li></a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        <?php endif; ?>
                   </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.common', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP Matsiko\new\resources\views/show.blade.php ENDPATH**/ ?>