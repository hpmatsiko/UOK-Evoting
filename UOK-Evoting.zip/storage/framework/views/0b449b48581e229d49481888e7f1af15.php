
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
<style>
    /* General Styles */
    body {
        font-family: Arial, sans-serif;
    }

    .navbar{
        background-color: #e88310;
        padding: 1rem;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        z-index: 99999999999;
    }
    .navbar-brand img {
        height: 70px;
    }

    .navbar-nav .nav-link {
        color: black;
        font-weight: 500;
        text-transform: capitalize;
    }

    .navbar-nav .nav-link:hover {
        color: #006600;
    }

    .dropdown-menu {
        border-radius: 0;
        border: none;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    }

    .dropdown-item:hover {
        background-color: #f8f9fa;
    }

    .navbar-toggler {
        border: none;
    }

    .navbar-toggler:focus {
        outline: none;
    }

    .form-inline {
        display: flex;
        align-items: center;
    }

    .form-inline input {
        border: none;
        border-bottom: 1px solid #ccc;
        border-radius: 0;
        margin-right: 0.5rem;
    }

    .form-inline input:focus {
        box-shadow: none;
    }

    @media (max-width: 991px) {
        .navbar-collapse {
            background-color: black;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            margin-top: 1rem;
            padding: 1rem;
        }

        .navbar-nav {
            margin-top: 1rem;
        }

        .navbar-nav .nav-item {
            margin-bottom: 1rem;
        }

        .form-inline {
            flex-direction: column;
            align-items: flex-start;
        }

        .form-inline input {
            margin-bottom: 0.5rem;
            width: 100%;
        }
    }
</style>

<?php
                                // Generate a random hex color
$randomColor = sprintf('#%06X', mt_rand(0, 0xFFFFFF));
?>
<nav style="background-color: <?php echo e($randomColor); ?>;" class="navbar navbar-expand-lg navbar-light navbar-custom sticky-top">
    <a class="navbar-brand wow zoomIn" href="<?php echo e(route('/')); ?>" data-wow-delay="0.3s">
        <img src="/img/logo.png" alt="Logo">
    </a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarContent" aria-controls="navbarContent" aria-expanded="false" aria-label="Toggle navigation" onclick="toggle()">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarContent">
        <ul class="navbar-nav ml-auto">
            <li class="nav-item dropdown">
                <a class="nav-link wow zoomIn" href="#" id="languageDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" data-wow-delay="0.5s">
                    <form class="form-inline">
                        <input class="form-control" type="search" id="search" placeholder="<?php echo app('translator')->get('messages.search_book'); ?>" aria-label="Search">
                        <?php
                                // Generate a random hex color
                        $randomColor = sprintf('#%06X', mt_rand(0, 0xFFFFFF));
                        ?>
                        <button class="btn" type="submit" style="background-color:<?php echo e($randomColor); ?>; color: black;">
                            <i class="fas fa-search"></i>
                        </button>
                    </form>
                </a>
            </li>
            <li class="nav-item dropdown">
                <a style="color: black;" class="nav-link dropdown-toggle wow zoomIn" href="#" id="schoolCategoryDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" data-wow-delay="0.7s">
                    <?php echo app('translator')->get('messages.school_category'); ?>
                </a>
                <div class="dropdown-menu" aria-labelledby="schoolCategoryDropdown">
                    <?php $__currentLoopData = $bookCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bookCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a class="dropdown-item" href="<?php echo e(url('/categoriesView', $bookCategory->id)); ?>"><?php echo e($bookCategory->book_category); ?></a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </li>
            <li class="nav-item dropdown">
                <a style="color: black;" class="nav-link dropdown-toggle wow zoomIn" href="#" id="languageDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" data-wow-delay="0.9s">
                    <i class="fas fa-globe"></i> <?php echo app('translator')->get('messages.Language'); ?>
                </a>
                <div class="dropdown-menu" aria-labelledby="languageDropdown">
                    <a class="dropdown-item" href="<?php echo e(route('locale', ['locale' => 'en'])); ?>"><?php echo app('translator')->get('messages.English'); ?></a>
                    <a class="dropdown-item" href="<?php echo e(route('locale', ['locale' => 'fr'])); ?>"><?php echo app('translator')->get('messages.French'); ?></a>
                    <a class="dropdown-item" href="<?php echo e(route('locale', ['locale' => 'kin'])); ?>"><?php echo app('translator')->get('messages.Kinyarwanda'); ?></a>
                </div>
            </li>
            <li class="nav-item">
                <a style="color: black;" href="<?php echo e(route('register')); ?>" class="nav-item nav-link wow zoomIn" data-wow-delay="1s"><?php echo app('translator')->get('messages.Register'); ?><i style="margin-left: 1vh;" class="fa-solid fa-user-pen"></i></a>
            </li>
            <li class="nav-item">
                <a style="color: black;" href="<?php echo e(route('login')); ?>" class="nav-item nav-link wow zoomIn" data-wow-delay="1.3s"><?php echo app('translator')->get('messages.Login'); ?><i style="margin-left: 1vh;" class="fas fa-sign-in-alt"></i></a>
            </li>
        </ul>
    </div>
</nav>

<div>
    <div class="container-xxl" style="z-index: 90000009; position: absolute; background: white;">
        <div class="container">
            <div class="row g-4" id="search_list">
            </div>
        </div>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

<script type="text/javascript">
    function toggle() {
        var content = document.querySelector('#navbarContent');
        if (content.style.display === 'block') {
            content.style.display = 'none';
        } else {
            content.style.display = 'block';
        }
    }

</script>

<?php /**PATH C:\Users\Administrator\hod\hod\resources\views/layouts/includes/header.blade.php ENDPATH**/ ?>