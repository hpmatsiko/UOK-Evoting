<style type="text/css">
    .nav-link.active {
        color: #198754 !important;
    }
</style>
<!-- Sidebar Start -->
<div class="sidebar pe-4 pb-3">
    <nav class="navbar bg-secondary navbar-dark">
        <a href="<?php echo e(route('teacher')); ?>" class="navbar-brand d-flex align-items-center px-4 px-lg-5">
            <h2 class="m-0" style="color:#000066; font-weight: 1000;">
                <img class="rounded-circle" style="height: 15vh; width: 15vh; margin-bottom: 5vh; margin-top: 1vh;" src="/img/logo.png" alt="">
            </h2>
        </a>
        <div class="navbar-nav w-100">
            <a href="<?php echo e(route('teacher')); ?>" class="nav-item nav-link <?php echo e(Request::routeIs('teacher') ? 'active' : ''); ?>" id="dsh" style="margin-bottom: 1.3vh; padding: 0vh; border-radius: 0vh;">
                <i class="fa fa-tachometer-alt me-2"></i>
                <span id="dash"><?php echo e(__('messages.dashboard')); ?></span>
            </a>

            <a href="<?php echo e(route('MyCourses')); ?>" class="nav-item nav-link <?php echo e(Request::routeIs('teacher') ? 'active' : ''); ?>" id="dsh" style="margin-bottom: 1.3vh; padding: 0vh; border-radius: 0vh;">
                <i class="fa fa-tachometer-alt me-2"></i>
                <span id="dash"><?php echo e(__('messages.my_courses')); ?></span>
            </a>
            <div class="nav-item dropdown">
                <a href="#" class="nav-link <?php echo e(Request::routeIs('ChooseBook', 'ChooseBookL') ? 'active' : ''); ?>" data-bs-toggle="dropdown" id="chapter" style="margin-bottom: 1.3vh; padding: 0vh; border-radius: 0vh;">
                    <i class="fa-solid fa-book-open me-2"></i>
                    <span id="chap"><?php echo e(__('messages.chapters')); ?></span>
                </a>
                <div class="dropdown-menu bg-transparent border-0">
                    <a href="<?php echo e(route('ChooseBook')); ?>" class="dropdown-item"><?php echo e(__('messages.add_chapter')); ?></a>
                    <a href="<?php echo e(route('ChooseBookL')); ?>" class="dropdown-item"><?php echo e(__('messages.chapter_list')); ?></a>
                </div>
            </div>
            <div class="nav-item dropdown">
                <a href="#" class="nav-link <?php echo e(Request::routeIs('ChooseBookChap', 'ChooseBookLN') ? 'active' : ''); ?>" data-bs-toggle="dropdown" id="note" style="margin-bottom: 1.3vh; padding: 0vh; border-radius: 0vh;">
                    <i class="fa fa-file-alt me-2"></i>
                    <span id="not"><?php echo e(__('messages.notes')); ?></span>
                </a>
                <div class="dropdown-menu bg-transparent border-0">
                    <a href="<?php echo e(route('ChooseBookChap')); ?>" class="dropdown-item"><?php echo e(__('messages.add_note')); ?></a>
                    <a href="<?php echo e(route('ChooseBookLN')); ?>" class="dropdown-item"><?php echo e(__('messages.notes_list')); ?></a>
                </div>
            </div>
            <div class="nav-item dropdown">
                <a href="#" class="nav-link <?php echo e(Request::routeIs('ChooseBookEx', 'ChooseBookLE') ? 'active' : ''); ?>" data-bs-toggle="dropdown" id="exer" style="margin-bottom: 1.3vh; padding: 0vh; border-radius: 0vh;">
                    <i class="fa fa-dumbbell me-2"></i>
                    <span id="ex"><?php echo e(__('messages.exercises')); ?></span>
                </a>
                <div class="dropdown-menu bg-transparent border-0">
                    <a href="<?php echo e(route('ChooseBookEx')); ?>" class="dropdown-item"><?php echo e(__('messages.add_exercise')); ?></a>
                    <a href="<?php echo e(route('ChooseBookLE')); ?>" class="dropdown-item"><?php echo e(__('messages.exercises_list')); ?></a>
                </div>
            </div>
            <div class="nav-item dropdown">
                <a href="#" class="nav-link <?php echo e(Request::routeIs('ChooseEx', 'ChooseBookLQ') ? 'active' : ''); ?>" data-bs-toggle="dropdown" id="ques" style="margin-bottom: 1.3vh; padding: 0vh; border-radius: 0vh;">
                    <i class="fa-solid fa-question me-2"></i>
                    <span id="que"><?php echo e(__('messages.questions')); ?></span>
                </a>
                <div class="dropdown-menu bg-transparent border-0">
                    <a href="<?php echo e(route('ChooseBookQ')); ?>" class="dropdown-item"><?php echo e(__('messages.add_question')); ?></a>
                    <a href="<?php echo e(route('ChooseBookLQ')); ?>" class="dropdown-item"><?php echo e(__('messages.question_list')); ?></a>
                </div>

            </div>

            


        </div>
    </nav>
</div>
<!-- Sidebar End -->



<script>
    document.addEventListener('DOMContentLoaded', function() {
        const navLinks = document.querySelectorAll('.nav-link');

        navLinks.forEach(link => {
            link.addEventListener('click', function() {
                // Remove 'active' class from all links
                navLinks.forEach(nav => nav.classList.remove('active'));

                // Add 'active' class to the clicked link
                this.classList.add('active');
            });
        });
    });
</script>


<?php /**PATH C:\Users\Administrator\Desktop\--\resources\views//admin/layouts/includes/sidebar.blade.php ENDPATH**/ ?>