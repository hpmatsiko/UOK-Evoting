 
<?php $__env->startSection('title', 'Add Question'); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('admin/layouts/includes/navA', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<style type="text/css">
    #que {
        color: darkblue;
    } 
    #ques {
        background: #000000;
    } 
</style>

<div style="margin: 4vh 4vh 0vh 4vh;" class="col-sm-12 col-xl-10">
    <div class="bg-secondary rounded h-100 p-4">
       <!-- Display Success Message -->
       <?php if(session('suc')): ?>
       <div class="alert alert-success">
        <?php echo e(session('suc')); ?>

    </div>
    <?php endif; ?>
    <form action="<?php echo e(route('exam.storeQuestion')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        
        <div class="row mb-3">
            <div class="col-sm-12">
                <select id="locale" name="locale" class="form-control <?php $__errorArgs = ['locale'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                    <option value="en" <?php echo e(app()->getLocale() == 'en' ? 'selected' : ''); ?>>English</option>
                    <option value="fr" <?php echo e(app()->getLocale() == 'fr' ? 'selected' : ''); ?>>French</option>
                    <option value="kin" <?php echo e(app()->getLocale() == 'kin' ? 'selected' : ''); ?>>Kinyarwanda</option>

                </select>
                <?php $__errorArgs = ['locale'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>
        <div>
            <label>Question:</label>
            <input type="hidden" name="ex_id" value="<?php echo e($exercise->id); ?>" placeholder="">
            <textarea name="question" class="form-control" rows="5" required></textarea>
        </div>
        <div class="row mb-3">
            <div class="col-sm-12">
                <label>Type:</label>
                <select name="type" required class="form-control">
                    <option value="single">Single Answer</option>
                    <option value="multiple">Multiple Answers</option>
                </select>
            </div>
        </div>
        <div id="answers" class="row mb-3">
            <div class="col-sm-12">
                <label>Answer:</label>
                <input type="text" name="answers[0][answer]" class="form-control" required>
                <label>Correct:</label>
                <input type="checkbox" name="answers[0][is_correct]" value="1">
                <label>Marks:</label>
                <input type="number" name="answers[0][marks]" class="form-control" min="0" required>
            </div>
        </div>
        <div class="row mb-3">
            <div class="col-sm-12">
                <button type="button" style="background: #198754;border: none;color: darkgrey;margin-right:4vh;padding: 1vh;border-radius: .7vh;" class="" onclick="addAnswer()">Add Another Answer</button>
                <button style="background: #198754;border: none;color: darkgrey;border-radius: .7vh;" type="submit" class="btn btn-primary">Submit</button>
            </div>
        </div>
    </form>
</div>
</div>

<script>
    let answerCount = 1;
    function addAnswer() {
        const answersDiv = document.getElementById('answers');
        const newAnswerDiv = document.createElement('div');
        newAnswerDiv.classList.add('col-sm-12', 'mt-3'); // Add classes for consistent styling
        newAnswerDiv.innerHTML = `
        <label>Answer:</label>
        <input type="text" name="answers[${answerCount}][answer]" class="form-control" required>
        <label style="margin-right:1vh;">Correct:</label>
        <input style="margin-right:3vh;" type="checkbox" name="answers[${answerCount}][is_correct]" value="1">
        <label>Marks:</label>
        <input type="number" name="answers[${answerCount}][marks]" class="form-control" min="0" required>
        <button type="button" style="border: none;color: darkgrey;margin-top:1vh;" class="btn btn-danger btn-sm" onclick="removeAnswer(this)">Close</button>
    `;
    answersDiv.appendChild(newAnswerDiv);
    answerCount++;
}

function removeAnswer(button) {
    const answerDiv = button.parentElement;
    answerDiv.remove();
}
</script>
<?php echo $__env->make('admin/layouts/includes/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin/layouts.commonA', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Administrator\hod\resources\views/questions/create_question.blade.php ENDPATH**/ ?>