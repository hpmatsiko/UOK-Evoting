
<?php $__env->startSection('title','Home Page'); ?>
<?php $__env->startSection('content'); ?>
 <div class="container-xxl py-5">
    <div class="container">
        <div style="display: flex;justify-content: space-around;" class="row g-4">
        	<h1 style="text-transform: uppercase;"><?php echo e($category->book_category); ?> <?php echo e($subCat->sub_category); ?></h1>
        	
<h3><?php echo e($book->bname); ?></h3>



        <div class="col-lg-3 col-sm-0 wow fadeInUp" data-wow-delay="0.7s" style="word-break: break-all;">
    <div class="service-item text-center pt-3">
        <div class="p-4" style="text-align: left;">
            <?php if($chapters->isEmpty()): ?>
                <p>No chapters in this book.</p>
            <?php else: ?>
                <?php $__currentLoopData = $chapters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chapter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <h5 style="line-height: 5vh;"><?php echo e($chapter->chapter); ?></h5>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </div>
    </div>
</div>

<div class="col-lg-9 col-sm-12 wow fadeInUp" data-wow-delay="0.7s" style="word-break: break-all;">
    <?php if($firstChapter): ?>
        <div class="service-item text-center pt-3">
            <div class="p-4" style="text-align: left;">
                <h3>Chapter: <?php echo e($firstChapter->chapter); ?></h3>
                <?php if($notes->isEmpty()): ?>
                    <p>No notes in this chapter.</p>
                <?php else: ?>
                    <ul>
                        <?php $__currentLoopData = $notes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $note): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a class="boh" href="<?php echo e(route('login')); ?>" style="padding: 4vh;">
                                <li><?php echo e($note->note); ?></li>
                            </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                <?php endif; ?>
            </div>
        </div>
    <?php else: ?>
        <p>No chapters available for this book.</p>
    <?php endif; ?>
</div>

    </div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.common', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP Matsiko\new\resources\views/user/viewbook.blade.php ENDPATH**/ ?>