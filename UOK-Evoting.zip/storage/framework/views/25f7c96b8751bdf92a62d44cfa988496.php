
<?php $__env->startSection('title', 'Home Page'); ?>
<?php $__env->startSection('content'); ?>
<div class="">
    <div class="">
        <div class="row g-4">

            

            <div class="col-lg-4 col-sm-12 wow fadeInUp bg-white shadow" data-wow-delay="0.7s" style="word-break: break-all;">
                <div class="service-item text-center pt-3">
                    <div class="p-4" style="text-align: left;">

                        <h3 class="category-header" style="background: #06BBCC; color: white; padding: 1.5vh; border-radius: 1vh;">
                            
                            <span style="font-weight: 1000;"><?php echo e($book->bname); ?></span>
                        </h3>

                        <h4 class="level-header" style="background: #06BBCC; color: white; padding: 1.5vh; border-radius: 1vh;">
                            <span style="font-weight: 1000; border-radius: 100vh; padding: 1vh; margin-top: 20vh"><?php echo e($levels->level); ?></span>
                        </h4>

                        <?php if($chapters->isEmpty()): ?>
                            <p>No chapters in this book.</p>
                        <?php else: ?>
                            <?php $__currentLoopData = $chapters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chapter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a href="<?php echo e(route('viewbookT', $chapter->id)); ?>">
                                    <h5 style="line-height: 5vh;"><?php echo e($chapter->chapter); ?></h5>
                                </a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>

                    </div>
                </div>
            </div>

            <div class="col-lg-8 col-sm-12 wow fadeInUp bg-white shadow" data-wow-delay="0.7s" style="word-break: break-all;">
                <?php if($firstChapter): ?>
                    <div class="service-item text-center pt-3">
                        <div class="p-4" style="text-align: left;">
                            <h3 class="chapter-header" style="background: #06BBCC; color: white; padding: 1.5vh; border-radius: 1vh;">
                                Chapter: <?php echo e($firstChapter->chapter); ?>

                            </h3>
                            
                            <?php if($notes->isEmpty()): ?>
                                <p>No notes in this chapter.</p>
                            <?php else: ?>
                                <?php $__currentLoopData = $notes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $note): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <a class="boh" href="<?php echo e(route('login')); ?>" style="padding: 4vh;">
                                        <?php echo $note->note; ?>

                                    </a>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>

                            <?php
                                $ChapterExercises = \App\Models\ExerciseModel::where('chapter_id', $firstChapter->id)->get();
                            ?>

                            <?php $__currentLoopData = $ChapterExercises; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exercise): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $marks = \App\Models\DoneEx::where('ex_id', $exercise->id)
                                        ->where('user_id', Auth::user()->id)
                                        ->orderBy('created_at', 'desc')
                                        ->first();
                                ?>

                                <div>
                                    <h3 class="exercise-header" style="background: #06BBCC; color: white; padding: 1.5vh; border-radius: 1vh;">
                                        <?php echo e($exercise->ex); ?> :
                                        <span style="font-weight: 800; color: darkred;">
                                            <?php echo e($marks ? round($marks->marks, 2) : 0); ?>%
                                        </span>
                                    </h3>

                                    <?php
                                        $ExerciseQuestions = \App\Models\Question::where('ex_id', $exercise->id)->get();
                                    ?>

                                    <form id="exam-form" action="<?php echo e(route('exam.submit')); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <ol>
                                            <input type="hidden" name="ex_id" value="<?php echo e($exercise->id); ?>">
                                            <?php $__currentLoopData = $ExerciseQuestions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div>
                                                    <li>
                                                        <h5><?php echo e($question->question); ?></h5>
                                                        <?php if($question->type == 'single'): ?>
                                                            <?php
                                                                $QuestionAnswers = \App\Models\Answer::where('question_id', $question->id)->get();
                                                            ?>
                                                            <?php $__currentLoopData = $QuestionAnswers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $answer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <label>
                                                                    <input type="radio" name="answers[<?php echo e($question->id); ?>]" value="<?php echo e($answer->id); ?>">
                                                                    <?php echo e($answer->answer); ?>

                                                                </label><br>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        <?php elseif($question->type == 'multiple'): ?>
                                                            <?php $__currentLoopData = $question->answers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $answer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <label>
                                                                    <input type="checkbox" name="answers[<?php echo e($question->id); ?>][]" value="<?php echo e($answer->id); ?>">
                                                                    <?php echo e($answer->answer); ?>

                                                                </label><br>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        <?php endif; ?>
                                                    </li>
                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ol>
                                        <button style="background: #06BBCC; border: none; padding: 1vh; border-radius: 1vh; color: ghostwhite; margin-top: 2vh;" type="submit">
                                            Submit
                                        </button>
                                    </form>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                <?php else: ?>
                    <p>No chapters available for this book.</p>
                <?php endif; ?>
            </div>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.common', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP Matsiko\hod\resources\views/user/viewbook.blade.php ENDPATH**/ ?>