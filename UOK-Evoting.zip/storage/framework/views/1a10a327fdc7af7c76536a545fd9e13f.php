<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH C:\Users\USER\Desktop\hd1\resources\views/vendor/mail/text/button.blade.php ENDPATH**/ ?>