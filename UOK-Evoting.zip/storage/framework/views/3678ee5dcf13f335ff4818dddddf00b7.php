
<style type="text/css" media="screen">
   .ourb h1{
    text-transform: capitalize;
} 

</style>

<div class="container-xxl py-5">
    <div class="container">
        <div style="" class="row g-4">

       <?php $__currentLoopData = $content; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cont): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php echo $cont->content; ?>

       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>




<div class="container-xxl py-5">
    <div class="container">
        <div style="display: flex;justify-content: space-around;" class="row g-4">

         <?php $__currentLoopData = $bookCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bookCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         
         <?php $__currentLoopData = $bookCategory->subCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <div class="col-lg-4 col-sm-12 bg-white shadow wow fadeInUp" data-wow-delay="0.3s" style="word-break: break-all;">
             <div class="service-item text-center pt-3" >
                <div class="p-4" style="text-align: left;">
                    <h5><?php echo e($bookCategory->book_category); ?></h5>
                    <h6><?php echo e($subCategory->sub_category); ?></h6>
                    
                    <ul> 
                    <?php $__currentLoopData = $subCategory->books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>           
                        <a href="<?php echo e(route("login")); ?>" style="padding: 4vh;"><li class="boh"><?php echo e($book->bname); ?></li></a>
                    
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                        </div>
            </div>
        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



    </div>
</div>
</div>






<?php /**PATH C:\Users\HP Matsiko\new\resources\views/layouts/includes/services.blade.php ENDPATH**/ ?>