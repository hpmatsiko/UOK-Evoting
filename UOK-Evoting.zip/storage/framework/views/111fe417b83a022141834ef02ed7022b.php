<?php $__env->startSection('content'); ?>
<?php echo $__env->make('admin/layouts/includes/navA', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<style type="text/css">
    #ibn{
        color: darkblue;
    }
    #ibt{
        background: #000000;
    }
</style>
<div class="container-fluid pt-4 px-4">
    <div class="row g-4">
        <div class="col-sm-12 col-xl-6">
          <div class="col-12">
            <div class="bg-secondary rounded h-100 p-4">
               <!-- Display Success Message -->
               <?php if(session('suc')): ?>
               <div class="alert alert-success">
                <?php echo e(session('suc')); ?>

            </div>
            <?php endif; ?>
            <h6 style="color: darkgrey;" class="mb-4">Category List</h6>
            <div class="table-responsive">
                <?php if($Categories ->isEmpty()): ?>
                <div class="container-fluid pt-4 px-4">
                    <div class="row g-4">


                        <div class="col-sm-12 col-xl-6">
                            <div class="bg-secondary rounded h-100 p-4" style="color: darkgrey;">

                                <p>No any category found </p>
                            </div>
                        </div>




                    </div>
                </div>
                <?php endif; ?>


                <table class="table">
                    <thead>
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">Category Name</th>
                            <th scope="col">Action</th>

                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $Categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $bookCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th scope="row"><?php echo e($index + 1); ?>)</th>
                            <td><?php echo e($bookCategory->category); ?></td>
                            <td>

                             <form action="<?php echo e(route('destroyC', $bookCategory->id)); ?>" method="POST" onsubmit="return confirm('Are you sure you want to delete?');">
                              <a href="<?php echo e(route('UpdateCat',$bookCategory->id)); ?>" class="btn btn-success btn-sm" style="margin-right: 2vh;color: darkgrey;">Edit</a>

                              <?php echo csrf_field(); ?>
                              <?php echo method_field('DELETE'); ?>
                              <button class="btn btn-danger btn-sm" style="color: darkgrey;" type="submit">Remove</button>
                          </form>
                      </td>

                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
          </table>


      </div>
  </div>
</div>

</div>
</div>
</div>
<?php echo $__env->make('admin/layouts/includes/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin/layouts.commonA', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\Desktop\hd1\resources\views/admin/CategoryL.blade.php ENDPATH**/ ?>