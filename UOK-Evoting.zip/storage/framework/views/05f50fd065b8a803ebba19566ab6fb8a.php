<?php $__env->startSection('title','Home Page'); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.includes.services', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script type="text/javascript">
  function mvh() {
    var hid=document.querySelector('#forg');
    if (hid.style.display=='none') {
      hid.style.display='block';
      document.querySelector('.center2').style.display='none';
    } else {
      hid.style.display='none';
    }
  }
</script>
<?php
                                // Generate a random hex color
$randomColor = sprintf('#%06X', mt_rand(0, 0xFFFFFF));
?>
<div id="forg" class="d-flex justify-content-center bg-white shadow" style="display: flex; width: 100%;">
  <div class="wow zoomIn bg-white shadow animate__animated animate__zoomIn" data-wow-delay="1.5s" style="position: absolute; top: 30%; padding: 0; border-radius: 2vh; width: 50%;z-index: 900000; ">
    <a href="<?php echo e(route("/")); ?>"><div style="background: <?php echo e($randomColor); ?>;" class="cr"><i class="fa-solid fa-xmark" style="color: black;"></i></div></a>
    <div class="form_container mt-5">
      <?php if(session()->has('suc')): ?>
      <!-- Display success message -->
      <div class="alert alert-success">
        <?php echo e(session('suc')); ?>

      </div>
      <?php endif; ?>
      <?php if (isset($component)) { $__componentOriginal7c1bf3a9346f208f66ee83b06b607fb5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7c1bf3a9346f208f66ee83b06b607fb5 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.auth-session-status','data' => ['class' => 'mb-4','status' => session('status')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('auth-session-status'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mb-4','status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(session('status'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7c1bf3a9346f208f66ee83b06b607fb5)): ?>
<?php $attributes = $__attributesOriginal7c1bf3a9346f208f66ee83b06b607fb5; ?>
<?php unset($__attributesOriginal7c1bf3a9346f208f66ee83b06b607fb5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7c1bf3a9346f208f66ee83b06b607fb5)): ?>
<?php $component = $__componentOriginal7c1bf3a9346f208f66ee83b06b607fb5; ?>
<?php unset($__componentOriginal7c1bf3a9346f208f66ee83b06b607fb5); ?>
<?php endif; ?>
      <form name="form" id="register2" action="<?php echo e(route('login')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <div>
          <div class="form_wrap">
            <div class="form_item mb-3">
              <input id="email" class="form-control" type="email" name="email" :value="old('username')" required autofocus autocomplete="username" placeholder="<?php echo app('translator')->get('messages.email'); ?>"/>
              <?php if (isset($component)) { $__componentOriginalf94ed9c5393ef72725d159fe01139746 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf94ed9c5393ef72725d159fe01139746 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['messages' => $errors->get('email'),'class' => 'mt-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['messages' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors->get('email')),'class' => 'mt-2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $attributes = $__attributesOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__attributesOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $component = $__componentOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__componentOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
              </div>
            </div>
            <div class="form_wrap">
              <div class="form_item mb-3">
                <input id="password" class="form-control" type="password" name="password" required autocomplete="current-password" placeholder="<?php echo app('translator')->get('messages.password'); ?>"/>
                <?php if (isset($component)) { $__componentOriginalf94ed9c5393ef72725d159fe01139746 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf94ed9c5393ef72725d159fe01139746 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['messages' => $errors->get('password'),'class' => 'mt-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['messages' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors->get('password')),'class' => 'mt-2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $attributes = $__attributesOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__attributesOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $component = $__componentOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__componentOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
                </div>
              </div>
              <div class="btn mt-4">
                <!-- Remember Me -->
                <div class="form-check">
                  <input id="remember_me" type="checkbox" class="form-check-input" name="remember">
                  <label for="remember_me" class="form-check-label">
                    <span style="color: black;" class="ms-2 text-sm"><?php echo app('translator')->get('messages.remember_me'); ?></span>
                  </label>
                </div>
                <div class="d-flex justify-content-end mt-4">
                  <?php if(Route::has('password.request')): ?>
                  <a style="color: black;" class="text-sm text-gray-600 hover:text-gray-900" href="<?php echo e(route('password.request')); ?>">
                    <?php echo app('translator')->get('messages.forgot_your_password'); ?>
                  </a>
                  <?php endif; ?> 
                  <?php
                                // Generate a random hex color
                  $randomColor = sprintf('#%06X', mt_rand(0, 0xFFFFFF));
                  ?>
                  <button type="submit" class="btn ms-3" style="background:<?php echo e($randomColor); ?>; border: none; color: black;">
                    <?php echo app('translator')->get('messages.Login'); ?>
                  </button>
                </div>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>

    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.common', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP Matsiko\hd\resources\views/auth/login.blade.php ENDPATH**/ ?>