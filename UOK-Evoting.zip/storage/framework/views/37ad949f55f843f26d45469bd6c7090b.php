<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH C:\Users\Uok Student\Desktop\--\resources\views/vendor/mail/text/header.blade.php ENDPATH**/ ?>