<?php echo e($slot); ?>

<?php /**PATH C:\Users\HP Matsiko\new\resources\views/vendor/mail/text/footer.blade.php ENDPATH**/ ?>