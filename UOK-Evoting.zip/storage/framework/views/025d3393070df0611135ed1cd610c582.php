<?php $__env->startSection('title','Home Page'); ?>
<?php $__env->startSection('content'); ?>

<script type="text/javascript">
  function mvh() {
    var hid=document.querySelector('#forg');
    if (hid.style.display=='none') {
      hid.style.display='block';
      document.querySelector('.center2').style.display='none';
    } else {
      hid.style.display='none';
    }
  }
</script>
<?php
                                // Generate a random hex color
$randomColor = sprintf('#%06X', mt_rand(0, 0xFFFFFF));
?>
<div id="forg" class="d-flex justify-content-center shadow" style="display: flex; width: 100%;background:wheat">
  <div class="wow shadow " data-wow-delay="1.5s" style="background: wheat;position: absolute; top: 30%; padding: 0; border-radius: 2vh; width: 50%;z-index: 900000; ">

    <div style="background: wheat"  class="form_container mt-5">

      <?php if(session('message')): ?>
      <div class="alert alert-success">
          <?php echo e(session('message')); ?>

      </div>
  <?php endif; ?>
      <?php if (isset($component)) { $__componentOriginal7c1bf3a9346f208f66ee83b06b607fb5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7c1bf3a9346f208f66ee83b06b607fb5 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.auth-session-status','data' => ['class' => 'mb-4','status' => session('status')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('auth-session-status'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mb-4','status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(session('status'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7c1bf3a9346f208f66ee83b06b607fb5)): ?>
<?php $attributes = $__attributesOriginal7c1bf3a9346f208f66ee83b06b607fb5; ?>
<?php unset($__attributesOriginal7c1bf3a9346f208f66ee83b06b607fb5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7c1bf3a9346f208f66ee83b06b607fb5)): ?>
<?php $component = $__componentOriginal7c1bf3a9346f208f66ee83b06b607fb5; ?>
<?php unset($__componentOriginal7c1bf3a9346f208f66ee83b06b607fb5); ?>
<?php endif; ?>
      <form style="background: wheat" name="form" id="register2" action="<?php echo e(route('key')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <div>
          <div class="form_wrap">
            <div class="form_item mb-3">
              <input id="regN" class="form-control" type="regN" name="regN" :value="old('regN')" required autofocus autocomplete="regN" placeholder="Put REN to Request Voting Key"/>
              <?php if (isset($component)) { $__componentOriginalf94ed9c5393ef72725d159fe01139746 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf94ed9c5393ef72725d159fe01139746 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['messages' => $errors->get('regN'),'class' => 'mt-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['messages' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors->get('regN')),'class' => 'mt-2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $attributes = $__attributesOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__attributesOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $component = $__componentOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__componentOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
              </div>
            </div>


                <div class="d-flex justify-content-end mt-4">

                  <?php
                                // Generate a random hex color
                  $randomColor = sprintf('#%06X', mt_rand(0, 0xFFFFFF));
                  ?>
                  <button type="submit" class="btn ms-3" style="background:<?php echo e($randomColor); ?>; border: none; color: black;">
                    Request Key
                  </button>
                </div>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>

    <?php $__env->stopSection(); ?>

<?php echo $__env->make('user.common', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\Desktop\voting\resources\views/user/vk.blade.php ENDPATH**/ ?>