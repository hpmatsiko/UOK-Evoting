
<?php $__env->startSection('title', 'Add Book Category'); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('admin/layouts/includes/nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="container-fluid pt-4 px-4">

    <div class="row g-4">
        <div style="" class="col-sm-12 col-xl-10">
            <div class="bg-secondary rounded h-100 p-4">

                <div class="form_container" style="margin-top: 6vh;">
                     <?php $__env->slot('header', null, []); ?> 
                        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
                            <?php echo e(__('Profile')); ?>

                        </h2>
                     <?php $__env->endSlot(); ?>

                    <div class="py-12">
                        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8 space-y-6">
                            <div class="p-4 sm:p-8  sm:rounded-lg">
                                <div class="max-w-xl">
                                    <?php echo $__env->make('profile.partials.update-profile-information-form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </div>
                            </div>

                            <div class="p-4 sm:p-8  sm:rounded-lg">
                                <div class="max-w-xl">
                                    <?php echo $__env->make('profile.partials.update-password-form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </div>
                            </div>

                            <div class="p-4 sm:p-8  sm:rounded-lg">
                                <div class="max-w-xl">
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin/layouts.common', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP Matsiko\hd\resources\views/admin/updateTProfile.blade.php ENDPATH**/ ?>