

<?php $__env->startSection('title', 'Add Book Category'); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('admin/layouts/includes/nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="container-fluid pt-4 px-4">
    <div class="row g-4">
 

 <?php if($questions->isEmpty()): ?>
        <div class="container-fluid pt-4 px-4">
    <div class="row g-4">

        
        <div class="col-sm-12 col-xl-6">
            <div class="bg-secondary rounded h-100 p-4" style="color: darkgrey;">
 
           No any question found!
            </div>
        </div>

       


    </div>
</div>


<?php else: ?>
        <div class="col-sm-12 col-xl-12">
          <div class="col-12">
            <div class="bg-secondary rounded h-100 p-4">
             <h6 style="color: darkgrey;" class="mb-4">Questions List</h6>

             <table border="1" class="table">
                <thead>
                    <tr>
                        <th>#</th>
                        <th scope="col">Question</th>
                        <th scope="col">Type</th>
                        <th scope="col">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        
                        <td  scope="row"><?php echo e($index + 1); ?>)</td>
                        
                        <td  scope="row"><?php echo e($question->question); ?></td>
                        <td scope="row"><?php echo e($question->type); ?></td>
                        <td scope="row">
                            <!-- Update and Delete Question -->
                            <a class="btn btn-success btn-sm" style="margin-right: 2vh;color: darkgrey;" href="<?php echo e(route('questions.edit', $question->id)); ?>">Edit Question</a>
                            <form action="<?php echo e(route('questions.destroy', $question->id)); ?>" method="POST" style="display: inline-block;">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button class="btn btn-danger btn-sm" style="color: darkgrey;" type="submit">Remove Question</button>
                            </form>
                            <br>

                            <!-- Display answers -->
                            <strong>Answers:</strong>
                            <ul>
                                <?php $__currentLoopData = $question->answers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $answer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li>
                                    <?php echo e($answer->answer); ?> (<?php echo e($answer->is_correct ? 'Correct' : 'Incorrect'); ?>)
                                    <a  class="btn btn-success btn-sm" style="margin-right: 2vh;color: darkgrey;margin-top: 1vh;" href="<?php echo e(route('answers.edit', $answer->id)); ?>">Edit Answer</a>
                                    <form action="<?php echo e(route('answers.destroy', $answer->id)); ?>" method="POST" style="display: inline-block;">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button class="btn btn-danger btn-sm" style="color: darkgrey;margin-top: 1vh;" type="submit">Remove Answer</button>
                                    </form>
                                </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
</div>
</div>
<?php endif; ?>
<?php echo $__env->make('admin/layouts/includes/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 

<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin/layouts.common', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP Matsiko\new\resources\views/questions/index.blade.php ENDPATH**/ ?>