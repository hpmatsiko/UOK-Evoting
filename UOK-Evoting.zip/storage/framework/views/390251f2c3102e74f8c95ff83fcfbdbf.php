
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
<style>
    /* General Styles */
    body {
        font-family: Arial, sans-serif;
    }

    .navbar-custom {
        background-color: white;
        padding: 1rem;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        padding-right: 3rem;
    }

    .navbar-brand img {
        height: 90px;
    }

    .navbar-nav .nav-link {
        color: black;
        font-weight: 500;
        text-transform: capitalize;
    }

    .navbar-nav .nav-link:hover {
        color: #006600;
    }

    .dropdown-menu {
        border-radius: 0;
        border: none;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);

    }

    .dropdown-item:hover {
        background-color: #f8f9fa;
    }

    .navbar-toggler {
        border: none;
    }

    .navbar-toggler:focus {
        outline: none;
    }

    .form-inline {
        display: flex;
        align-items: center;
    }

    .form-inline input {
        border: none;
        border-bottom: 1px solid #ccc;
        border-radius: 0;
        margin-right: 0.5rem;
    }

    .form-inline input:focus {
        box-shadow: none;
    }

    @media (max-width: 991px) {
        .navbar-collapse {
            background-color: white;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            margin-top: 1rem;
            padding: 1rem;
        }

        .navbar-nav {
            margin-top: 1rem;
        }

        .navbar-nav .nav-item {
            margin-bottom: 1rem;
        }

        .form-inline {
            flex-direction: column;
            align-items: flex-start;
        }

        .form-inline input {
            margin-bottom: 0.5rem;
            width: 100%;
        }
    }
</style>

<script type="text/javascript">
    function toggle()
    {
        var button=document.querySelector('.navbar-toggler');
        var content=document.querySelector('#navbarContent');
        if (content.style.display==='block') {
            content.style.display='none';
        }

        else
        {

            content.style.display='block';

        }
    }
</script>
<nav class="navbar navbar-expand-lg navbar-light navbar-custom sticky-top">
    <a class="navbar-brand" href="<?php echo e(route('user')); ?>">
        <img src="/img/logo.png" alt="Logo">
    </a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarContent" aria-controls="navbarContent" aria-expanded="false" aria-label="Toggle navigation" onclick="return toggle()">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse wow fadIn" id="navbarContent">
        <ul class="navbar-nav ml-auto">
            <li class="nav-item dropdown">
               <form class="form-inline">
                <input class="form-control" type="search" id="search" placeholder="<?php echo app('translator')->get('messages.search_book'); ?>" aria-label="Search">
                <button class="btn" type="submit" style="background-color: #06BBCC; border-color: #06BBCC; color: white;">
                    <i class="fas fa-search"></i>
                </button>
            </form>
            <div id="search_list" class="dropdown-menu" aria-labelledby="schoolCategoryDropdown">
             


            </div>
        </li>
        
        <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="schoolCategoryDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <?php echo app('translator')->get('messages.school_category'); ?>
            </a>
            <div class="dropdown-menu" aria-labelledby="schoolCategoryDropdown">
                <?php $__currentLoopData = $bookCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bookCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a class="dropdown-item" href="<?php echo e(route('showu', $bookCategory->id)); ?>"><?php echo e($bookCategory->book_category); ?></a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </li>

        <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="languageDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <i class="fas fa-globe"></i> <?php echo app('translator')->get('messages.Language'); ?>
            </a>
            <div class="dropdown-menu" aria-labelledby="languageDropdown">
                <a class="dropdown-item" href="<?php echo e(route('locale', ['locale' => 'en'])); ?>"><?php echo app('translator')->get('messages.English'); ?></a>
                <a class="dropdown-item" href="<?php echo e(route('locale', ['locale' => 'fr'])); ?>"><?php echo app('translator')->get('messages.French'); ?></a>
                <a class="dropdown-item" href="<?php echo e(route('locale', ['locale' => 'kin'])); ?>"><?php echo app('translator')->get('messages.Kinyarwanda'); ?></a>
            </div>
        </li>
        <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <?php echo e(Auth::user()->fname); ?> <?php echo e(Auth::user()->lname); ?>

            </a>
            <div class="dropdown-menu" aria-labelledby="userDropdown">
                <a class="dropdown-item" href="<?php echo e(route('profile.edit')); ?>"><?php echo app('translator')->get('messages.my_account'); ?></a>
                <form method="POST" action="<?php echo e(route('logout')); ?>">
                    <?php echo csrf_field(); ?>
                    <button class="dropdown-item" type="submit"><?php echo app('translator')->get('messages.logout'); ?></button>
                </form>
            </div>
        </li>
    </ul>
</div>
</nav>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<script>
    $(document).ready(function () {
        // Initialize Bootstrap tooltips and popovers
        $('[data-toggle="tooltip"]').tooltip();
        $('[data-toggle="popover"]').popover();

        // Toggle the collapse menu on small screens
        $('.navbar-toggler').click(function () {
            $('#navbarContent').collapse('toggle');
        });
    });
</script>

<?php /**PATH C:\Users\HP Matsiko\BB\resources\views/user/includes/header.blade.php ENDPATH**/ ?>