
<style type="text/css" media="screen">
   .ourb h1{
    text-transform: capitalize;
 } 

</style>

<div class="container-xxl py-5">
 <div class="container">
   <div style="display: flex;justify-content: space-around;" class="row g-4">

     <?php if($content->isEmpty()): ?>
     <?php else: ?>
           
         <?php $__currentLoopData = $content; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cont): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <div class="col-lg-6 col-sm-12 bg-white shadow wow zoomIn" data-wow-delay="0.3s" style="word-break: break-all;">
            <div class="service-item text-center pt-3" >
               <div class="p-4" style="text-align: left;">

                  <?php echo $cont->content; ?>


               </div>
            </div>
         </div>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         <?php endif; ?>

  

           <?php $__currentLoopData = $bookCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bookCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       <?php $__currentLoopData = $bookCategory->subCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       <div align="center">
        <h3><?php echo e($bookCategory->book_category); ?> - <?php echo e($subCategory->sub_category); ?></h3>

    </div>
    <?php $__currentLoopData = $subCategory->levels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $level): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php $__currentLoopData = $level->books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-lg-4 col-sm-12 bg-white shadow wow zoomIn" data-wow-delay="0.3s" style="word-break: break-all;">
     <div class="service-item text-center pt-3" >
        <div class="p-4" style="text-align: left;">

            <h5 class="alert alert-success" style="color: "><?php echo e($level->level); ?> - <?php echo e($book->bname); ?></h5>



            <a href="<?php echo e(route('viewbook',$book->id)); ?>" style="padding: 4vh;">

                <?php if($book->image): ?>
                <center>
                    <img src="/bookImages/<?php echo e($book->image); ?>" alt="book Image" style="width: 100%;height: 100%;">
                    <?php endif; ?>
                </center>
                <div align="center" class="alert " style="color: black;">
                    <?php echo $book->description = implode(' ', array_slice(str_word_count($book->description, 1), 0, 10)); ?>

                </div>
            </a>
            <div align="center" class="alert alert-success" >
                <span><i class="fas fa-shopping-cart" style="font-size: 5vh;margin-right: .5vh;"></i>Add to cart</span>
            </div>





        </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


 </div>
</div>
</div>






<?php /**PATH C:\Users\HP Matsiko\hod\resources\views/user/includes/services.blade.php ENDPATH**/ ?>