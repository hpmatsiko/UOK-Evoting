<style type="text/css">
    .nav-link.active {
        color: #198754 !important;
    }
</style>
<!-- Sidebar Start -->
<div class="sidebar pe-4 pb-3">
    <nav class="navbar bg-secondary navbar-dark">
        <a href="<?php echo e(route('admin')); ?>" class="navbar-brand d-flex align-items-center px-4 px-lg-5">
            <h2 class="m-0" style="color:#000066; font-weight: 1000;">
                <img class="" style="height: 10vh; width: 20vh; margin-bottom: 5vh; margin-top: 1vh;" src="/img/logo.png" alt="">
            </h2>
        </a>
        <div class="navbar-nav w-100">
            <a href="<?php echo e(route('admin')); ?>" class="nav-item nav-link <?php echo e(Request::routeIs('admin') ? 'active' : ''); ?>" id="dsh" style="margin-bottom: 1.3vh; padding: 0vh; border-radius: 0vh;">
                <i class="fa fa-tachometer-alt me-2"></i>
                <span id="dash"><?php echo app('translator')->get('messages.dashboard'); ?></span>
            </a>
            

            <div class="nav-item dropdown">
                <a href="#" class="nav-link <?php echo e(Request::routeIs('addUser') ? 'active' : ''); ?>" data-bs-toggle="dropdown" id="ques" style="margin-bottom: 1.3vh; padding: 0vh; border-radius: 0vh;">
                    <i class="fa-solid fa-user me-2"></i>
                    <span id="que"><?php echo app('translator')->get('messages.users'); ?></span>
                </a>
                <div class="dropdown-menu bg-transparent border-0">
                    <a href="<?php echo e(route('addUser')); ?>" class="dropdown-item"><?php echo app('translator')->get('messages.add_user'); ?></a>
                    <a href="UserL" class="dropdown-item"><?php echo app('translator')->get('messages.user_list'); ?></a>
                </div>

            </div>


            <div class="nav-item dropdown">
                <a href="#" class="nav-link <?php echo e(Request::routeIs('addBookCat', 'CatL') ? 'active' : ''); ?>" data-bs-toggle="dropdown" id="ibt" style="margin-bottom: 1.3vh; padding: 0vh; border-radius: 0vh;">
                    <i class="fa fa-tags me-2"></i>
                    <span id="ibn"><?php echo app('translator')->get('messages.categories'); ?></span>
                </a>
                <div class="dropdown-menu bg-transparent border-0">
                    <a href="<?php echo e(route('addBookCat')); ?>" class="dropdown-item"><?php echo app('translator')->get('messages.add_category'); ?></a>
                    <a href="<?php echo e(route('CatL')); ?>" class="dropdown-item"><?php echo app('translator')->get('messages.categories_list'); ?></a>
                </div>
            </div>
            <div class="nav-item dropdown">
                <a href="#" class="nav-link <?php echo e(Request::routeIs('ChooseCat', 'SubCatL') ? 'active' : ''); ?>" data-bs-toggle="dropdown" id="subb" style="margin-bottom: 1.3vh; padding: 0vh; border-radius: 0vh;">
                    <i class="fa fa-tag me-2"></i>
                    <span id="sub"><?php echo app('translator')->get('messages.sub_categories'); ?></span>
                </a>
                <div class="dropdown-menu bg-transparent border-0">
                    <a href="<?php echo e(route('ChooseCat')); ?>" class="dropdown-item"><?php echo app('translator')->get('messages.add_sub_category'); ?></a>
                    <a href="<?php echo e(route('SubCatL')); ?>" class="dropdown-item"><?php echo app('translator')->get('messages.sub_categories_list'); ?></a>
                </div>
            </div>
            <div class="nav-item dropdown">
                <a href="#" class="nav-link <?php echo e(Request::routeIs('ChooseCat', 'SubCatL') ? 'active' : ''); ?>" data-bs-toggle="dropdown" id="lev" style="margin-bottom: 1.3vh; padding: 0vh; border-radius: 0vh;">
                    <i class="fas fa-level-up-alt"></i>

                    <span id="le"><?php echo app('translator')->get('messages.levels'); ?></span>
                </a>
                <div class="dropdown-menu bg-transparent border-0">
                    <a href="<?php echo e(route('ChooseSubCatL')); ?>" class="dropdown-item"><?php echo app('translator')->get('messages.add_level'); ?></a>
                    <a href="<?php echo e(route('Levels')); ?>" class="dropdown-item"><?php echo app('translator')->get('messages.levels_list'); ?></a>
                </div>
            </div>
            <div class="nav-item dropdown">
                <a href="#" class="nav-link <?php echo e(Request::routeIs('ChooseSubCat', 'BookL') ? 'active' : ''); ?>" data-bs-toggle="dropdown" id="book" style="margin-bottom: 1.3vh; padding: 0vh; border-radius: 0vh;">
                    <i class="fa-solid fa-book me-2"></i>
                    <span id="boo"><?php echo app('translator')->get('messages.courses'); ?></span>
                </a>
                <div class="dropdown-menu bg-transparent border-0">
                    <a href="<?php echo e(route('ChooseLevel')); ?>" class="dropdown-item"><?php echo app('translator')->get('messages.add_course'); ?></a>
                    <a href="<?php echo e(route('BookL')); ?>" class="dropdown-item"><?php echo app('translator')->get('messages.course_list'); ?></a>
                </div>
            </div>

            <div class="nav-item dropdown">
                <a href="#" class="nav-link <?php echo e(Request::routeIs('ChooseSubCat', 'BookL') ? 'active' : ''); ?>" data-bs-toggle="dropdown" id="tcs" style="margin-bottom: 1.3vh; padding: 0vh; border-radius: 0vh;">
                    <i class="fa-solid fa-book me-2"></i>
                    <span id="tc"><?php echo app('translator')->get('messages.courses_teachers'); ?></span>
                </a>
                <div class="dropdown-menu bg-transparent border-0">
                    <a href="<?php echo e(route('assignCourseToTeacher')); ?>" class="dropdown-item"><?php echo app('translator')->get('messages.add_course_to_teacher'); ?></a>

                    


                    <a href="<?php echo e(route('TeacherCourseL')); ?>" class="dropdown-item"><?php echo app('translator')->get('messages.courses_teacher_list'); ?></a>
                </div>
            </div>

            
            <div class="nav-item dropdown">
                <a href="#" class="nav-link <?php echo e(Request::routeIs('ChooseEx', 'ChooseBookLQ') ? 'active' : ''); ?>" data-bs-toggle="dropdown" id="conte" style="margin-bottom: 1.3vh; padding: 0vh; border-radius: 0vh;">
                    <i class="fa-solid fa-home me-2"></i>
                    <span id="cont"><?php echo app('translator')->get('messages.home_contents'); ?></span>
                </a>
                <div class="dropdown-menu bg-transparent border-0">
                    <a href="<?php echo e(route('addContent')); ?>" class="dropdown-item"><?php echo app('translator')->get('messages.add_home_content'); ?></a>
                    <a href="<?php echo e(route('AllContent')); ?>" class="dropdown-item"><?php echo app('translator')->get('messages.home_content_list'); ?></a>
                </div>
            </div>
        </div>
    </nav>
</div>
<!-- Sidebar End -->



<script>
    document.addEventListener('DOMContentLoaded', function() {
        const navLinks = document.querySelectorAll('.nav-link');

        navLinks.forEach(link => {
            link.addEventListener('click', function() {
                // Remove 'active' class from all links
                navLinks.forEach(nav => nav.classList.remove('active'));

                // Add 'active' class to the clicked link
                this.classList.add('active');
            });
        });
    });
</script>


<?php /**PATH C:\Users\Administrator\hd\resources\views//admin/layouts/includes/sidebarA.blade.php ENDPATH**/ ?>