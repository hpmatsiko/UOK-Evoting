
<style type="text/css" media="screen">
   .ourb h1{
    text-transform: capitalize;
 } 

</style>

<div>
   <div class="">
   <div style="display: flex;justify-content: space-around;" class="row g-4">

     <?php if($content->isEmpty()): ?>
     <?php else: ?>
           
         <?php $__currentLoopData = $content; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cont): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        

                  <?php echo $cont->content; ?>


         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         <?php endif; ?>

  

           <?php $__currentLoopData = $bookCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bookCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       <?php $__currentLoopData = $bookCategory->subCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php $__currentLoopData = $subCategory->levels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $level): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       <div align="center">
         <p class="nav-link" style="font-weight: bold;color: ;font-size: 5vh"><?php echo e($bookCategory->book_category); ?> - <?php echo e($subCategory->sub_category); ?> - <?php echo e($level->level); ?> </p>

    </div>
   
    <?php $__currentLoopData = $level->books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-lg-4 col-sm-12 bg-white shadow wow zoomIn" data-wow-delay="0.3s" style="word-break: break-all;">
     <div class="service-item text-center pt-3" >
        <div class="p-4" style="text-align: left;">

            <h5 class="" style="background: #06BBCC;color: white;border-radius: 1vh;padding: 1.5vh;"><?php echo e($book->bname); ?> <span style="font-weight: 800;"><?php echo e($book->price); ?>Frw</span></h5>



            <a href="<?php echo e(route("login")); ?>" style="padding: 4vh;">

                <?php if($book->image): ?>
                <center>
                    <img src="/bookImages/<?php echo e($book->image); ?>" alt="book Image" style="width: 100%;height: 100%;">
                    <?php endif; ?>
                </center>
                <div align="center" class="alert " style="color: grey;">
                    <?php echo $book->description = implode(' ', array_slice(str_word_count($book->description, 1), 0, 10)); ?>

                </div>
            </a>
            <div align="center" class="" style="background: #06BBCC;color: white;border-radius: 1vh;padding: 1.5vh;">
                <span><i class="fas fa-shopping-cart" style="font-size: 3vh;margin-right: .5vh;"></i>Add to cart</span>
            </div>





        </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


 </div>
</div>
</div>






<?php /**PATH C:\Users\HP Matsiko\BB\resources\views/layouts/includes/services.blade.php ENDPATH**/ ?>