

<?php $__env->startSection('title', 'Add Book Category'); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('admin/layouts/includes/navA', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<style type="text/css" media="screen">
        #not{
        color: darkblue;
    } 
    #note{
        background: #000000;
    }
</style>
<div class="container-fluid pt-4 px-4">
    <div class="row g-4">

        <a class="col-sm-12 col-xl-6" href="<?php echo e(route('ChooseChap',$book->id)); ?>">
        <div class="col-sm-12 col-xl-6">
            <div class="bg-secondary rounded h-100 p-4" style="color: darkgrey;">
 
            <?php echo e($book->bname); ?>

            </div>
        </div>

        </a>


    </div>
</div>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<?php echo $__env->make('admin/layouts/includes/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin/layouts.commonA', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP Matsiko\BB\resources\views/admin/ChooseBookChap.blade.php ENDPATH**/ ?>