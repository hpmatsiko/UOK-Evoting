  <?php if(Route::has('login')): ?>


  
  <?php $__env->startSection('title', 'Dashboard'); ?>

  <?php $__env->startSection('content'); ?>

  <!-- Content Start -->

  <!-- Navbar Start -->
  <?php echo $__env->make('/admin/layouts/includes/navA', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <!-- Navbar End -->

  <style type="text/css" media="screen">
    #dash{
        color: darkblue;
    } 
    #dsh{
        background: #000000;
    } 
</style>
<!-- Sale & Revenue Start -->
<div class="container-fluid pt-4 px-4">
    <div class="row g-4">
        <div class="col-sm-6 col-xl-3">
            <div class="bg-secondary rounded d-flex align-items-center justify-content-between p-4">
                <i class="fa fa-tags me-2" style="color:darkblue;font-size: 4vh;"></i>
                <div class="ms-3">
                    <p class="mb-2"><?php echo app('translator')->get('messages.categories'); ?></p>
                    <h6 style="color:#198754;" class="mb-0">$1234</h6>
                </div>
            </div>
        </div>
        <div class="col-sm-6 col-xl-3">
            <div class="bg-secondary rounded d-flex align-items-center justify-content-between p-4">
                <i class="fa fa-book" style="color:darkblue;font-size: 4vh;"></i>
                <div class="ms-3">
                    <p class="mb-2"><?php echo app('translator')->get('messages.courses'); ?></p>
                    <h6 style="color:#198754;" class="mb-0">$1234</h6>
                </div>
            </div>
        </div>
      
        <div class="col-sm-6 col-xl-3">
            <div class="bg-secondary rounded d-flex align-items-center justify-content-between p-4">
                <i class="fa fa-user" style="color:darkblue;font-size: 4vh;"></i>
                <div class="ms-3">
                    <p class="mb-2"><?php echo app('translator')->get('messages.students'); ?></p>
                    <h6 style="color:#198754;" class="mb-0">$1234</h6>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Sale & Revenue End -->

<?php echo $__env->make('/admin/layouts/includes/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 

<!-- Content End -->

<?php $__env->stopSection(); ?>
<?php endif; ?> 



<?php echo $__env->make('/admin/layouts.commonA', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP Matsiko\BB\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>