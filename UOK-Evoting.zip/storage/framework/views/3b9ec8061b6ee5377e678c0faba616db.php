<?php $__env->startSection('title', 'User List'); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('admin/layouts/includes/navA', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="container-fluid pt-4 px-4">
    <h6 class="mb-4">User List</h6>

    
    <?php if(session('suc')): ?>
    <div class="alert alert-success">
        <?php echo e(session('suc')); ?>

    </div>
    <?php endif; ?>

    <div class="bg-secondary rounded h-100 p-4">
        <div class="table-responsive">  <!-- Responsive Table Wrapper -->
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Registration Number</th>
                        <th>Email</th>
                        <th>Phone</th>
                        <th>First Name</th>
                        <th>Last Name</th>
                        <th>Gender</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($user->id); ?></td>
                        <td><?php echo e($user->regN); ?></td>
                        <td><?php echo e($user->email); ?></td>
                        <td><?php echo e($user->phone); ?></td>
                        <td><?php echo e($user->fname); ?></td>
                        <td><?php echo e($user->lname); ?></td>
                        <td><?php echo e($user->gender); ?></td>
                        <td>
                            <a href="<?php echo e(route('profile.edit', $user->id)); ?>" class="btn btn-success btn-sm">Edit</a>
                            <form action="<?php echo e(route('profile.destroy', $user->id)); ?>" method="POST" style="display:inline;">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this user?');">Delete</button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>

        <!-- Pagination -->
        <nav aria-label="User pagination">
            <div class="d-flex justify-content-center">
                <ul class="pagination">
                    <li class="page-item <?php echo e($users->onFirstPage() ? 'disabled' : ''); ?>">
                        <a class="page-link" href="<?php echo e($users->previousPageUrl()); ?>" aria-label="Previous">
                            <span aria-hidden="true">&laquo;</span>
                        </a>
                    </li>

                    <?php $__currentLoopData = $users->getUrlRange(1, $users->lastPage()); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="page-item <?php echo e($page == $users->currentPage() ? 'active' : ''); ?>">
                            <a class="page-link" href="<?php echo e($url); ?>"><?php echo e($page); ?></a>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <li class="page-item <?php echo e($users->hasMorePages() ? '' : 'disabled'); ?>">
                        <a class="page-link" href="<?php echo e($users->nextPageUrl()); ?>" aria-label="Next">
                            <span aria-hidden="true">&raquo;</span>
                        </a>
                    </li>
                </ul>
            </div>
        </nav>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin/layouts.commonA', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\The Ghost\Desktop\voting\resources\views/admin/UserL.blade.php ENDPATH**/ ?>