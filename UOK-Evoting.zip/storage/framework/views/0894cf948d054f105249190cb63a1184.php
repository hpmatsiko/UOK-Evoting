<?php $__env->startSection('title', 'Candidates List'); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('admin/layouts/includes/navA', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<style type="text/css">
    .card {
        transition: transform 0.2s; /* Smooth scaling on hover */
    }
    .card:hover {
        transform: scale(1.02); /* Scale up on hover */
    }
    .card-header {
        background-color: #343a40; /* Dark background for the card header */
        color: white; /* White text for card header */
    }
    .candidate-image {
        width: 70px; /* Fixed width for candidate images */
        height: 70px; /* Fixed height for candidate images */
        border-radius: 50%; /* Circular image */
    }
    .alert {
        margin-bottom: 1rem; /* Bottom margin for alerts */
        border-radius: .25rem; /* Rounded corners for alerts */
    }
    .pagination {
        justify-content: center;
        margin-top: 20px;
    }
    .pagination .page-item.active .page-link {
        background-color: #2EB872; /* Active background color */
        border-color: #2EB872; /* Active border color */
        color: white; /* Active text color */
    }
    .pagination .page-link {
        color: #2EB872; /* Link color */
        border: 1px solid #2EB872; /* Border color */
        padding: 0.5rem 0.75rem; /* Padding */
    }
    .pagination .page-link:hover {
        background-color: #2EB872; /* Hover background color */
        color: white; /* Hover text color */
    }
    .pagination .page-item.disabled .page-link {
        color: #ccc; /* Disabled color */
        pointer-events: none; /* Prevent click */
    }
</style>

<div class="container-fluid pt-4 px-4">
    <h6 class="mb-4">Candidates List</h6>

    <?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <div class="row">
        <?php if($candidates->isEmpty()): ?>
            <div class="col-12">
                <div class="bg-secondary rounded h-100 p-4" style="color: darkgrey;">
                    <h5>No candidates found</h5>
                </div>
            </div>
        <?php else: ?>
            <?php $__currentLoopData = $candidates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $candidate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-4 mb-4">
                    <div class="card">
                        <div class="card-header">
                            <h5 class="mb-0"><?php echo e($candidate->user->fname); ?> <?php echo e($candidate->user->lname); ?></h5>
                        </div>
                        <div class="card-body">
                            <div class="text-center">
                                <img src="<?php echo e(asset('images/'.$candidate->user->image)); ?>" alt="Candidate Image" class="candidate-image mb-2">
                            </div>

                            <p><strong>Email:</strong> <?php echo e($candidate->user->email); ?></p>
                            <p><strong>Phone:</strong> <?php echo e($candidate->user->phone); ?></p>
                            <p><strong>Category:</strong> <?php echo e($candidate->category->category ?? 'N/A'); ?></p>
                            <p><strong>Date of Birth:</strong> <?php echo e($candidate->user->dob); ?></p>
                            <p><strong>Gender:</strong> <?php echo e($candidate->user->gender); ?></p>
                            <p><strong>Nationality:</strong> <?php echo e($candidate->user->nationality); ?></p>
                            <p><strong>Marital Status:</strong> <?php echo e($candidate->user->marital_status); ?></p>
                            <p><strong>Department:</strong> <?php echo e($candidate->user->department); ?></p>
                            <p><strong>Program Type:</strong> <?php echo e($candidate->user->program_type); ?></p>
                            <p><strong>Program:</strong> <?php echo e($candidate->user->program); ?></p>
                            <p><strong>Program Mode:</strong> <?php echo e($candidate->user->program_mode); ?></p>
                            <p><strong>Intake:</strong> <?php echo e($candidate->user->intake); ?></p>
                            <p><strong>Status</strong> <button type="submit" class="btn btn-danger btn-sm"><?php echo e($candidate->status); ?></button></p>
                            <div class="text-center">
                                <a href="<?php echo e(asset('cvs/'.$candidate->cvpdf)); ?>" target="_blank" class="btn btn-success">View CV</a>
                                <!-- Confirm and Reject buttons -->
                                <form method="POST" action="<?php echo e(route('candidates.confirm', $candidate->id)); ?>" style="display:inline;">
                                    <?php echo csrf_field(); ?>

                                    <button type="submit" class="btn  btn-sm" style="background: blue;color:antiquewhite">Confirm</button>
                                </form>
                                <form method="POST" action="<?php echo e(route('candidates.reject', $candidate->id)); ?>" style="display:inline;">
                                    <?php echo csrf_field(); ?>

                                    <button type="submit" class="btn  btn-sm" style="background: rgb(128, 0, 96);color:antiquewhite">Reject</button>
                                </form>
                            </div>

                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </div>

    <!-- Improved Pagination -->
    <nav aria-label="Candidates pagination">
        <ul class="pagination">
            <li class="page-item <?php echo e($candidates->onFirstPage() ? 'disabled' : ''); ?>">
                <a class="page-link" href="<?php echo e($candidates->previousPageUrl()); ?>" aria-label="Previous">
                    <span aria-hidden="true">&laquo;</span>
                </a>
            </li>
            <?php for($i = 1; $i <= $candidates->lastPage(); $i++): ?>
                <li class="page-item <?php echo e($i == $candidates->currentPage() ? 'active' : ''); ?>">
                    <a class="page-link" href="<?php echo e($candidates->url($i)); ?>"><?php echo e($i); ?></a>
                </li>
            <?php endfor; ?>
            <li class="page-item <?php echo e($candidates->hasMorePages() ? '' : 'disabled'); ?>">
                <a class="page-link" href="<?php echo e($candidates->nextPageUrl()); ?>" aria-label="Next">
                    <span aria-hidden="true">&raquo;</span>
                </a>
            </li>
        </ul>
    </nav>
</div>

<?php echo $__env->make('admin/layouts/includes/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin/layouts.commonA', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\Desktop\voting\resources\views/admin/candidate_list.blade.php ENDPATH**/ ?>