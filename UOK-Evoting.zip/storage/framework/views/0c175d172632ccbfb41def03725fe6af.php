
<?php $__env->startSection('title', 'Add Book Category'); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('admin/layouts/includes/navA', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<style type="text/css">
    #le{
        color: darkblue;
    } 
    #lev{
        background: #000000;
    } 
</style>
<div class="container-fluid pt-4 px-4">
    <div class="row g-4">
        <div class="col-sm-12 col-xl-12">
          <div class="col-12">
            <div class="bg-secondary rounded h-100 p-4">
                <h6 style="color: darkgrey;" class="mb-4">Levels List</h6>
                <div class="table-responsive">
                    <?php if($bookCategories->isEmpty()): ?>
                    <div class="container-fluid pt-4 px-4">
                        <div class="row g-4">


                            <div class="col-sm-12 col-xl-6">
                                <div class="bg-secondary rounded h-100 p-4" style="color: darkgrey;">

                                    <p>No any level found </p>
                                </div>
                            </div>




                        </div>
                    </div>
                    <?php endif; ?>


                    <table class="table">
                        <thead>
                            <tr>
                                <th scope="col">#</th>

                                <th>School Category</th>
                                <th scope="col">Sub-category Name</th>
                                <th scope="col">Level</th>
                                <th scope="col">Action</th>

                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $bookCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bookcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php $__currentLoopData = $bookcategory->subCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php $__currentLoopData = $subcategory->levels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $level): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th scope="row"><?php echo e($index + 1); ?>)</th>
                                <th scope="row"><?php echo e($bookcategory->book_category); ?></th>
                                <td scope="row"><?php echo e($subcategory->sub_category); ?></td>
                                <td scope="row"><?php echo e($level->level); ?></td>
                                <td scope="row"> <a href="<?php echo e(route('UpdateLevel',$level->id)); ?>" class="btn btn-success btn-sm" style="margin-right: 2vh;color: darkgrey;">Edit</a><a href="" class="btn btn-danger btn-sm" style="color: darkgrey;">Remove</a></td>

                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>


                </div>
            </div>
        </div>

    </div>
</div>
</div>
<?php echo $__env->make('admin/layouts/includes/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin/layouts.commonA', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP Matsiko\BB\resources\views/admin/Levels.blade.php ENDPATH**/ ?>