<?php $__env->startSection('title','Home Page'); ?>
<?php $__env->startSection('content'); ?>

<script type="text/javascript">
  function mvh() {
      var hid=document.querySelector('#forg');
      if (hid.style.display=='none') {
        hid.style.display='block';
        document.querySelector('.center2').style.display='none';
    }

    else{
        hid.style.display='none';
    }
}
</script>
<div  id="forg"  style="z-index: 10000899;display: flex;justify-content: center;">
    <div class="wow zoomIn bg-white shadow" data-wow-delay="1.5s" style="position: absolute;top: 30%;background: white;padding: 15vh;border-radius: 2vh;width: 60%;">
        <a href="<?php echo e(route("/")); ?>"><div class="cr"><i class="fa-solid fa-xmark"></i></div></a>
        <div class="mb-4 text-sm text-gray-600" style="color:;">
            <?php echo e(__('Thanks for signing up! Before getting started, could you verify your email address by clicking on the link we just emailed to you? If you didn\'t receive the email, we will gladly send you another.')); ?>

        </div>

        <?php if(session('status') == 'verification-link-sent'): ?>
        <div style="color: #06BBCC;" class="mb-4 font-medium text-sm text-green-600">
            <?php echo e(__('A new verification link has been sent to the email address you provided during registration.')); ?>

        </div>
        <?php endif; ?>

        <div class="mt-4 flex items-center justify-between">
            <form method="POST" action="<?php echo e(route('verification.send')); ?>">
                <?php echo csrf_field(); ?>

                <div>
                    <?php if (isset($component)) { $__componentOriginald411d1792bd6cc877d687758b753742c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald411d1792bd6cc877d687758b753742c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.primary-button','data' => ['style' => 'background: #06BBCC;border: none;']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('primary-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['style' => 'background: #06BBCC;border: none;']); ?>
                        <?php echo e(__('Resend Verification Email')); ?>

                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald411d1792bd6cc877d687758b753742c)): ?>
<?php $attributes = $__attributesOriginald411d1792bd6cc877d687758b753742c; ?>
<?php unset($__attributesOriginald411d1792bd6cc877d687758b753742c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald411d1792bd6cc877d687758b753742c)): ?>
<?php $component = $__componentOriginald411d1792bd6cc877d687758b753742c; ?>
<?php unset($__componentOriginald411d1792bd6cc877d687758b753742c); ?>
<?php endif; ?>
                </div>
            </form>

          
        </div>
    </div>
</div>
<?php echo $__env->make('layouts.includes.services', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.common', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Administrator\Desktop\--\resources\views/auth/verify-email.blade.php ENDPATH**/ ?>