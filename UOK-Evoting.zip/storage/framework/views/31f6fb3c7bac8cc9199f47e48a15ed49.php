<style type="text/css" media="screen">
   .ourschools
   {
    width: 170vh;
    display:flex;
    justify-content: space-around;
    padding:7vh;
}

</style>
<div>

    <div class="ourschools">

        <!-- Add your preferred icon library (e.g., Font Awesome) -->
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">

        <div class="nav-item dropdown wow fadeInUp">
            <a style="background:#fff;color: black; font-size: 18px;padding: 0;" href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown"><?php echo app('translator')->get('messages.school_category'); ?></a>
            <div class="dropdown-menu fade-down m-0 wow fadeInUp">
                <?php $__currentLoopData = $bookCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bookCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                <a class="dropdown-item" href="<?php echo e(url('/categoriesView', $bookCategory->id)); ?>"><?php echo e($bookCategory->book_category); ?></a>
                
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>


        <div style="z-index: 200000000000;" class="nav-item dropdown wow fadeInUp">
            <a style="background:#fff;color: black; font-size: 18px;padding: 0;" href="#" class="nav-link" data-bs-toggle="dropdown"> <div class="search-input-caret-jump wow fadeInUp" data-wow-delay="0.2s" style=" font-size: 18px;">
        <input type="text" name="search" id="search" placeholder="<?php echo app('translator')->get('messages.search_book'); ?>" class="form-control" onfocus="this.value=''" style="padding: 0;">
              <button><i class="fas fa-search"></i></button>
          </div></a>
          <div  id="search_list" class="dropdown-menu fade-down m-0 wow fadeInUp">

          </div>
      </div>


      <div>

        <div class="nav-item dropdown wow fadeInUp" data-wow-delay="0.3s">
           <div style="display: flex;justify-content: center;align-items: center;">

               <a style="background:#fff;color: black; font-size: 18px;padding: 0;margin-right: 3vh;" href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown"><i  style="font-size:;margin-right: 1vh;" class="fa-solid fa-globe i"></i><?php echo app('translator')->get('messages.Language'); ?></a>
           </div> 
           <div class="dropdown-menu fade-down m-0 wow fadeInUp">
            <a href="<?php echo e(route('locale', ['locale' => 'en'])); ?>" class="dropdown-item"><?php echo app('translator')->get('messages.English'); ?></a>
            <a href="<?php echo e(route('locale', ['locale' => 'fr'])); ?>" class="dropdown-item"><?php echo app('translator')->get('messages.French'); ?></a>
            <a href="<?php echo e(route('locale', ['locale' => 'kin'])); ?>" class="dropdown-item"><?php echo app('translator')->get('messages.Kinyarwanda'); ?></a>

        </div>
    </div> 
</div>
<a href="<?php echo e(route('register')); ?>" class="rgrg start-btn"><?php echo app('translator')->get('messages.Register'); ?><i style="margin-left: 1vh;" class="fa-solid fa-user-pen"></i></a>
<a href="<?php echo e(route('login')); ?>" class="rgrg start-btn2"><?php echo app('translator')->get('messages.Login'); ?><i style="margin-left: 1vh;" class="fas fa-sign-in-alt"></i>
</a>
</div>

</div><?php /**PATH C:\Users\Uok Student\Desktop\--\resources\views/layouts/includes/ourschool.blade.php ENDPATH**/ ?>