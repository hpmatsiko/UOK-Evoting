
<style type="text/css" media="screen">
 .ourb h1{
    text-transform: capitalize;
} 

</style>



<?php if($content->isEmpty()): ?>
<?php else: ?>

<?php $__currentLoopData = $content; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cont): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


<?php echo $cont->content; ?>



<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<?php $__currentLoopData = $bookCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bookCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php $__currentLoopData = $bookCategory->subCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
<?php $__currentLoopData = $subCategory->levels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $level): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="container-xxl py-5">
    <div class="container">
        <div class="row g-4">

            <div align="center">
                <h3><?php echo e($bookCategory->book_category); ?> - <?php echo e($subCategory->sub_category); ?> - <?php echo e($level->level); ?></h3>
            </div>

            
            <?php $delay = 0.1; ?> <!-- Reset delay for each level -->
            <?php $__currentLoopData = $level->books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                                // Generate a random hex color
            $randomColor = sprintf('#%06X', mt_rand(0, 0xFFFFFF));
            ?>
            <div class="col-lg-3 col-sm-12 bg-black shadow wow zoomIn" data-wow-delay="<?php echo e($delay); ?>s" style="word-break: break-all;">
                <div class="service-item text-center pt-3">
                    <div class="p-4" style="text-align: center;">

                        <h6 class="books" style="background:<?php echo e($randomColor); ?>;color: black;padding: 1vh"><?php echo e($book->bname); ?></h6>

                       <a href="<?php echo e(route('viewbook',$book->id)); ?>" style="padding: 4vh;">

                        <?php if($book->image): ?>
                        <center>
                            <img src="/bookImages/<?php echo e($book->image); ?>" alt="book Image" style="width: 100%;height: 100%;">
                        </center>
                        <?php endif; ?>
                    </a>
                </div>
            </div>
        </div>
        <?php 
        $delay += 0.3;
        if ($loop->iteration % 4 == 0) {
                    $delay = 0.1; // reset delay after every 4 books
                }
                ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>




</div>
</div>
</div>






<?php /**PATH C:\Users\USER\Desktop\hd1\resources\views/user/includes/services.blade.php ENDPATH**/ ?>