  <?php if(Route::has('login')): ?>


  
  <?php $__env->startSection('title', 'Dashboard'); ?>

  <?php $__env->startSection('content'); ?>

  <!-- Content Start -->

  <!-- Navbar Start -->
  <?php echo $__env->make('/admin/layouts/includes/nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <!-- Navbar End -->

  <style type="text/css" media="screen">
    #dash{
        color: darkblue;
    } 
    #dsh{
        background: #000000;
    } 
</style>
<!-- Sale & Revenue Start -->





<div class="container-fluid pt-4 px-4">
    <div class="row g-4">
      <div class="container-fluid pt-4 px-4">
        <div class="row g-4">
            <?php if($courseCount ==0): ?>
            <div class="col-sm-6 col-xl-4">
                <div class="bg-secondary rounded d-flex align-items-center justify-content-between p-4">
                    <i class="fa fa-chart-line fa-3x" style="color:darkblue;"></i>
                    <div class="ms-3">
                        <p class="mb-2"><?php echo e(__('messages.my_courses')); ?></p>
                        <h6 style="color:#198754;" class="mb-0">
                            <?php echo e(__('messages.no_course')); ?>

                        </h6>
                    </div>
                </div>
            </div>
            <?php else: ?>
            <div class="col-sm-6 col-xl-3">
                <div class="bg-secondary rounded d-flex align-items-center justify-content-between p-4">
                    <i class="fa fa-chart-line fa-3x" style="color:darkblue;"></i>
                    <div class="ms-3">
                        <p class="mb-2"><?php echo e(__('messages.my_courses')); ?></p>
                        <h6 style="color:#198754;" class="mb-0">
                            <?php echo e($courseCount); ?>

                        </h6>
                    </div>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>

</div>
</div>
<!-- Sale & Revenue End -->

<?php echo $__env->make('/admin/layouts/includes/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 

<!-- Content End -->

<?php $__env->stopSection(); ?>
<?php endif; ?> 



<?php echo $__env->make('/admin/layouts.common', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP Matsiko\hd\resources\views/admin/Tdashboard.blade.php ENDPATH**/ ?>