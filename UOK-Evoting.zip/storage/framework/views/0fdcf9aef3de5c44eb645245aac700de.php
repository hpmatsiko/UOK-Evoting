
<?php $__env->startSection('title','Home Page'); ?>
<?php $__env->startSection('content'); ?>
<div class="">
    <div class="">
        <div style="" class="row g-4">
        	

            <div class="col-lg-4 col-sm-0 wow fadeInUp bg-white shadow" data-wow-delay="0.7s" style="word-break: break-all;">
                <div class="service-item text-center pt-3">
                    <div class="p-4" style="text-align: left;">

                        <h3 style="background: #06BBCC;color: white;padding: 1.5vh;border-radius: 1vh;" style="text-transform: uppercase;">
                            
                            <span style="font-weight: 1000;">
                                <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php echo e($book->bname); ?>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </span>

                        </h3>

                        <h4 style="background: #06BBCC;color: white;padding: 1.5vh;border-radius: 1vh;">
                            <span style="font-weight: 1000;border-radius: 100vh;padding: 1vh;margin-top: 20vh">
                                <?php $__currentLoopData = $levels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $level): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                               <?php echo e($level->level); ?>

                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           </span>
                       </h4>

                       
                       <?php $__currentLoopData = $chapters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chapt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                       <a href="<?php echo e(route('viewbookT',$chapt->id)); ?>">
                        <h5 style="line-height: 5vh;"><?php echo e($chapt->chapter); ?></h5>
                    </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    

                </div>
            </div>
        </div>

        <div class="col-lg-8 col-sm-12 wow fadeInUp bg-white shadow" data-wow-delay="0.7s" style="word-break: break-all;">
           
            <div class="service-item text-center pt-3">
                <div class="p-4" style="text-align: left;">
                    <h3 style="background: #06BBCC;color: white;padding: 1.5vh;border-radius: 1vh;">Chapter: <?php echo e($chapter->chapter); ?></h3>
                    <?php if($notes->isEmpty()): ?>
                    <p>No notes in this chapter.</p>
                    <?php else: ?>

                    <?php $__currentLoopData = $notes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $note): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a class="boh" href="<?php echo e(route('login')); ?>" style="padding: 4vh;">
                       <?php echo $note->note; ?>

                   </a>
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                   <?php endif; ?>
                   
                   <?php $__currentLoopData = $exercises; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exercise): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   <?php
                   $marks = \App\Models\DoneEx::where('ex_id', $exercise->id)
                   ->where('user_id', Auth::user()->id)
                   ->orderBy('created_at', 'desc')
                   ->first();

                   ?>
                   <div>
                    <h3 class="" style="background: #06BBCC;color: white;padding: 1.5vh;border-radius: 1vh;"><?php echo e($exercise->ex); ?> : 
                      <?php if($marks): ?>
                      <span style="font-weight: 800;color: darkred;"><?php echo e(round($marks->marks,2)); ?>%</span>
                      <?php else: ?>
                      <span style="font-weight: 800;color: darkred;">0%</span>
                      <?php endif; ?>

                  </h3>
                  <?php
                      // Ensure $exercises is a query builder instance
                  $ExerciseQuestions = \App\Models\Question::where('ex_id', $exercise->id)->get();
                  ?>

                  <form id="exam-form" action="<?php echo e(route('exam.submit')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <ol>
                        <input type="hidden" name="ex_id" value="<?php echo e($exercise->id); ?>">
                        <?php $__currentLoopData = $ExerciseQuestions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div>

                            <li><h5><?php echo e($question->question); ?></h5>
                                <?php if($question->type == 'single'): ?>
                                <?php
                      // Ensure $exercises is a query builder instance
                                $QuestionAnswers = \App\Models\Answer::where('question_id', $question->id)->get();
                                ?>
                                <?php $__currentLoopData = $QuestionAnswers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $answer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <label>
                                    <input type="radio" name="answers[<?php echo e($question->id); ?>]" value="<?php echo e($answer->id); ?>">
                                    <?php echo e($answer->answer); ?>

                                </label><br>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                <?php elseif($question->type == 'multiple'): ?>

                                <?php $__currentLoopData = $question->answers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $answer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <label>
                                    <input type="checkbox" name="answers[<?php echo e($question->id); ?>][]" value="<?php echo e($answer->id); ?>">
                                    <?php echo e($answer->answer); ?>

                                </label><br>
                            </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <?php endif; ?>

                        </div>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ol>
                    <button style="background: #06BBCC;border: none;padding: 1vh;border-radius: 1vh;color: ghostwhite;border: none;margin-top: 2vh;" type="submit">Submit</button>
                </form>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
   
   
</div>

</div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.common', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP Matsiko\hod\resources\views/user/viewbookT.blade.php ENDPATH**/ ?>