<?php $__env->startSection('title', 'Add Candidate'); ?>
<?php $__env->startSection('content'); ?>

<style type="text/css">
    #teac {
        color: #6C7293;
    }
    #teach {
        background: #000000;
    }
</style>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<div class="container-fluid pt-4 px-4" style="margin-top: 6vh;">
    <div class="row g-4">
        <div class="col-sm-12 col-xl-6" style="background: wheat">
            <div class="rounded h-100 p-4">
                <h6 style="color: #198754;" class="mb-4">Candidate Registration</h6>

                <!-- Display Success Message -->
                <?php if(session('suc')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('suc')); ?>

                </div>
                <?php endif; ?>

                <!-- Display Error Messages -->
                <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
                <?php endif; ?>

                <form method="POST" action="<?php echo e(route('candidates.register')); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>

                    <!-- Hidden Category ID -->
                    <input type="hidden" name="category_id" value="<?php echo e($category->id); ?>" />

                    <!-- PDF Upload -->
                    <div class="row mb-3">
                        <div class="col-sm-12">
                            <label for="pdf">Upload PDF</label>
                            <input class="form-control" id="pdf" type="file" name="cvpdf" accept="application/pdf">
                        </div>
                    </div>

                    <!-- Image Upload -->


                    <!-- Submit Button -->
                    <div class="row mb-3">
                        <div class="col-sm-12">
                            <button style="background: #198754; border: none; color: white;" type="submit" class="btn btn-primary">
                                <?php echo e(__('Save')); ?>

                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php echo $__env->make('admin/layouts/includes/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.common', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\USER\Desktop\voting\resources\views/admin/AddCandidate.blade.php ENDPATH**/ ?>