<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('users', function (Blueprint $table) {
            $table->id();

            // Define the columns as needed
            $table->string('regN')->unique()->nullable(); // Registration Number
            $table->string('email')->unique(); // Email
            $table->string('phone')->unique(); // Phone number
            $table->string('fname')->nullable(); // First name
            $table->string('lname')->nullable(); // Last name
            $table->string('address')->nullable(); // Address
            $table->date('dob')->nullable(); // Date of Birth
            $table->string('department')->nullable(); // Department
            $table->string('gender')->nullable(); // Gender
            $table->string('marital_status')->nullable(); // Martial Status
            $table->string('nationality')->nullable(); // Nationality
            $table->string('national_passport_id')->nullable(); // National Passport ID
            $table->string('program_type')->nullable(); // Program Type
            $table->string('specialization')->nullable(); // Specialization
            $table->string('program')->nullable(); // Program
            $table->string('program_mode')->nullable(); // Program Mode
            $table->string('intake')->nullable(); // Intake
            $table->string('image')->nullable(); // Profile Image
            $table->string('usertype'); // User Type
            $table->timestamp('email_verified_at')->nullable(); // Email Verified At
            $table->string('password'); // Password
            $table->rememberToken(); // Remember Token
            $table->timestamps(); // Timestamps
        });

        Schema::create('password_reset_tokens', function (Blueprint $table) {
            $table->string('email')->primary();
            $table->string('token');
            $table->timestamp('created_at')->nullable();
        });

        Schema::create('sessions', function (Blueprint $table) {
            $table->string('id')->primary();
            $table->foreignId('user_id')->nullable()->index();
            $table->string('ip_address', 45)->nullable();
            $table->text('user_agent')->nullable();
            $table->longText('payload');
            $table->integer('last_activity')->index();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('users');
        Schema::dropIfExists('password_reset_tokens');
        Schema::dropIfExists('sessions');
    }
};
